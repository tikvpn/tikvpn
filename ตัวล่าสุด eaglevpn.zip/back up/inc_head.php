
<html>
<head>
<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<link rel="stylesheet"

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Charm&display=swap" rel="stylesheet">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet"  href="https://savat-vpn.online/assets/vendor/animate/animate.css"> 
</head>
<style>
body {
height : auto;
max-width : 100%;
width : 100%;


background-color : #FFFFFF;

font-family: 'charm';

color : #000000;
}
.btn-1{
							color:#fff;/*สีตัวหนังสือในปุ่ม*/
							background: #FF0000; 
    background: -webkit-linear-gradient(left top, blue, lightpink , black); 
    background: -o-linear-gradient(bottom right, lightpink, black); 
    background: -moz-linear-gradient(bottom right, blue, black); 
    background: linear-gradient(to bottom right, magenta, cyan);
border-color:#ffffff;/*เส้นขอบปุ่ม*/

							}
.btn-1:hover,.btn-1:focus,.btn-1.focus{
					color:#fff;/*สีตัวหนังสือในปุ่ม*/
					background:#FF0000;/*พื้นหลังปุ่ม*/
					border-color:#6962EC;/*เส้นขอบปุ่ม*/
					border-width: 0.5px;/*ขนาดของเส้นขอบปุ่ม*/
					}

</style>

<body>
<title>TIK-VPN</title>
<?php 

include ("navbar.php");
?>

<br />
<div class="container">

<center>
<div class="col-lg-6 wow fadeInUp animated " style="visibility: visible; animation-name: fadeInUp;"> 
   



</font>
</br>
<h1>TIK-VPN</h1>
<marquee scrolldelay="200" style="font-size: 16px;">
    ยินดีต้อนรับสู่เว็บไซต์ TIK NETFREE VPN ท่านสามารถสนับสนุนเราได้ที่เบอร์ wallet 1 wallet  ก็ยินดีครับหรือจะมากกว่าก็นั้นก็จะขอบพระคุณมากครับ
 
   </marquee> 

<img src="img/net.png" width="300dp" height="auto">

วิทยุออนไลน์ เพลงเพราะๆฟังต่อเนื่อง
<script type="text/javascript" src="https://hosted.muses.org/mrp.js"></script>
<script src="https://hosted.muses.org/mrp.js"></script>

<script type="text/javascript">
MRP.insert({
'url':'https://80sv2.hostpleng.com/?url=http://112.121.150.133:8020/stream',
'codec':'mp3',
'volume':100,
'autoplay':true,
'forceHTML5' :true,
'jsevents':true,
'buffering':0,
'title':'TIK-VPN Music_Radio',
'wmode':'transparent',
'skin':'faredirfare',
'width':269,
'height':52
});
</script>
<iframe src="//www.ondio.in/status/ondio_new_index.php" width="100%" height="20" frameborder="0" marginwidth="0" marginheight="0" scrolling="No"></iframe>
<div id="MusesRadioPlayer-HTML5-player-0" class="musesStyleReset" style="overflow: hidden; width: 100%; height: 52px; position: relative;">
</div>
</html>

