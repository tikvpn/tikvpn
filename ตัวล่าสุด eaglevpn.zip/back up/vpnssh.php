<?php
include ("inc_head.php");
?>
<div class="card" style="width: 18rem;"> <img src="img/tcp.png" class="card-img-top"
 alt="auto"> <div class="card-body"> <h5 class="card-title">เว็บไซต์ TCP VPN  </p> <a href="https://www.tcpvpn.com/vpn-server-thailand" class="btn btn-primary"> <i class="fa fa-user-plus" aria-hidden="true"></i> สมัครบัญชี</a> 

</div> 
</div>

<div class="card" style="width: 18rem;"> <img src="img/vpnget.png" class="card-img-top"
 alt="auto"> <div class="card-body"> <h5 class="card-title">เว็บไซต์ vpngate  </p> <a href="https://www.vpngate.net/en/" class="btn btn-primary"> <i class="fa fa-user-plus" aria-hidden="true"></i> สมัครบัญชี</a> 

</div> 
</div>

<div class="card" style="width: 18rem;"> <img src="img/tryv.png" class="card-img-top"
 alt="auto"> <div class="card-body"> <h5 class="card-title">เว็บไซต์ tryv.com  </p> <a href="https://tryvpn.com/account" class="btn btn-primary"> <i class="fa fa-user-plus" aria-hidden="true"></i> ไปที่เว็บไซต์</a> 

</div> 
</div>
 

 <center>
<p class="card-text">เว็บไซต์ vpnjantit.com  
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="https://www.vpnjantit.com/create-free-account.html?type=OpenVPN&server=premithai#create" class="btn btn-Success"><i class="fa fa-user-plus" aria-hidden="true"></i> สมัครบัญชี</a>
</br>

 <center>
<p class="card-text">เว็บไซต์ xamjyssvpn 
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="https://xamjyssvpn.xyz/pages/ovpn.php" class="btn btn-Success"><i class="fa fa-user-plus" aria-hidden="true"></i> สมัครบัญชี</a>
 </br>
<center>
<p class="card-text">เว็บไซต์ jagoanssh.com 
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="https://www.jagoanssh.com/?do=port-scanner" class="btn btn-Success"><i class="fa fa-user-plus" aria-hidden="true"></i> สมัครบัญชี</a>
</br>
<center>
<p class="card-text">เว็บไซต์ octopusvpn.xyz 
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="https://octopusvpn.xyz/server" class="btn btn-Success"><i class="fa fa-user-plus" aria-hidden="true"></i> สมัครบัญชี</a>
</br>
<center>
<p class="card-text">เว็บไซต์ octopusvpn 
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="https://octopusvpn.xyz/server" class="btn btn-Success"><i class="fa fa-user-plus" aria-hidden="true"></i> สมัครบัญชี</a>
</br>
<p class="card-text">เว็บไซต์ VPNSPLIT.COM
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="https://vpnsplit.com/" class="btn btn-Success"><i class="fa fa-user-plus" aria-hidden="true"></i> สมัครบัญชี</a>
<br>
<p class="card-text">เว็บไซต์ VPN.PHFREE.XYZ 
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="https://vpn.phfree.xyz/home/member/server" class="btn btn-Success"><i class="fa fa-user-plus" aria-hidden="true"></i> สมัครบัญชี</a>
</br>
</br>
 </p>
  </div>
<p class="card-text">เว็บไซต์ flyssh-ssl.com 
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="https://www.flyssh.com/create-ssl/214/server-ssl/tls-sg-1" class="btn btn-Success"><i class="fa fa-user-plus" aria-hidden="true"></i> สมัครบัญชี</a>
 </p>
  </div>






