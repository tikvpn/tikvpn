<nav class="navbar navbar-light bg-Dark">
  <a class="navbar-brand" href="/">
    <img src="img/icon.png" width="55" height="55" class="d-inline-block align-top" alt="" loading="lazy">
  <font color="#FFFFFF">TIK NETFREE
VPN
</font>

  </a>
</p>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-"></span>
  <font color="#FFFFFF">MENU
</font>
  </button>
 
        <div class="navbar-collapse collapse"
 id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="/"><font color="back"><button type="button" class="btn btn-outline-info"></font><font color="#33FFFF"><i class="fa fa-home"></font></i><font color="#FFFFFF"> หน้าแรก <span class="sr-only">(current)</span> </font></a>
      </li>
<li class="nav-item">
        <a class="nav-link" href="/login"><button type="button" class="btn btn-outline-info"><font color="#33FFFF"><i class="fa fa-sign-in"></i></font> <font color="#FFFFFF">เข้าสู่ระบบ</font></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="home.php"><button type="button" class="btn btn-outline-info"><font color="#33FFFF"><i class="fa fa-sign-in"></i></font><font color="#FFFFFF"> หน้าสมัครสมาชิก</font></a>
      </li>

<li class="nav-item">
        <a class="nav-link" href="vpnssh.php"><button type="button" class="btn btn-outline-info"><font color="#33FFFF"><i class="fa fa-internet-explorer" aria-hidden="true"></i></font><font color="#FFFFFF"> หน้าสมัครเว็บ OPENVPN SSH ต่างๆ</font></a>
      </li>


 <li class="nav-item ">
        <a class="nav-link" href="https://www.packetcp.com/vultrdns.php"><button type="button" class="btn btn-outline-info"><font color="33FFFF"><i class="fa fa-internet-explorer" aria-hidden="true"></i></font>  <span class="sr-only">(current)</span> <font color="#FFFFFF"> เว็บไซต์แปลง dns ฟรี</font></a>
      </li>

<li class="nav-item ">
        <a class="nav-link" href="webproxy.php"><button type="button" class="btn btn-outline-info"><font color="#33FFFF"><i class="fa fa-internet-explorer" aria-hidden="true"></i></font>  <span class="sr-only">(current)</span> <font color="#FFFFFF"> เว็บไซต์หาพร็อกซี่ ฟรี</font></a>
      </li>


<li class="nav-item ">
        <a class="nav-link" href="pecget.php"><button type="button" class="btn btn-outline-info"><font color=#33FFFF"><i class="fa fa-internet-explorer" aria-hidden="true"></i></font>  <span class="sr-only">(current)</span> <font color="#FFFFFF"> โปรเสริมที่เล่นเน็ต VPN.true dtac</font></a>
      </li>

<li class="nav-item ">
        <a class="nav-link" href="host.php"><button type="button" class="btn btn-outline-info"><font color="#33FFFF"><i class="fa fa-internet-explorer" aria-hidden="true"></i></font>  <span class="sr-only">(current)</span> <font color="#E0FFFF"> โฮสต์ เพลโหลด </font></a>
      </li>

</br>
               <center>
<marquee behavior="alternate"><overflow: hidden; width: 100%; height: 52px; position: relative;"> <b><font color="#FFFFFF" size="3">
<!-- Button trigger modal --> 
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#xxx"> 
 ช่องทางติดตาม 
</font></b></marquee></marquee>
<div class="card text-center mt-1 mb-3">

<div class="col-md-4">

<li class="nav-item ">
        <a class="nav-link" href="https://www.facebook.com/groups/1566231063554700/"> <button type="button" class="btn btn-outline-info"><font color="blue"> <img src="img/fb.png" width="18dp" height="auto"></font>  <span class="sr-only">(current)</span><font color="#9933FF"> NET FREE VPN</font></a>
      </li>


<li class="nav-item">
        <a class="nav-link" href="https://line.me/ti/g2/UkbDu_oGkf4kywRRpuluIA?utm_source=invitation&utm_medium=link_"><button type="button" class="btn btn-outline-info"><img src="img/line.png" width="18dp" height="auto"><font color="#9933FF"> กลุ่มไลน์เด็กไทย VPN</font></a>
      </li>


		 <li class="nav-item ">
        <a class="nav-link" href="https://www.youtube.com/channel/UCRD8KGuti061h14nIIEPWmQ"><font color="red"><button type="button" class="btn btn-outline-info"><i class="fa fa-youtube-play" aria-hidden="true"></i></font> <font color="#9933FF"> ติดตามผมงานทางช่องยูทูป</font></a>
      </li>

		 <li class="nav-item ">
        <a class="nav-link" href="https://tmn.app.link/XguJQ0MBvdb"><font color="red"><button type="button" class="btn btn-outline-info"><img src="img/wallet.png" width="30dp" height="auto></font> <font color="#FFFFFF"> ไปยังแอพ wallet สนับสนุน
<h3>เบอร์ วอเลต  </br>
0970046465</br>ไพบูลย์ ชัยยา</h3>
</font></a>

      </li>

<li class="nav-item ">
        <a class="nav-link" href="https://m.me/tik.chaiya"><font color="#3333FF"><button type="button" class="btn btn-outline-info"><i class="fa fa-commenting" aria-hidden="true"></i></font> <font color="#330066"> ติดต่อแอดมิน</font></a>
      </li>
    </ul>
<form action="" class="was-validated"  method="POST">


	</div>
</br>
</br>


    </form>
  
  </div>
</nav>

