<?php
include ("inc_head.php");
?>

<div class="card" style="width: 19rem;"> <img src="img/eagle.png" class="card-img-top"
 alt="auto"> <div class="card-body"> <h5 class="card-title">แอพEagle VPN GEMMER</h5> <p class="card-text">แอพสำหรับใช้เล่นเกมส์และเลานโซเชี่ยวต่างๆ VIPแอพนี้เน้นเกมส์ออนไลน์  มีทั้งทรูมูฟเละดีแทค ais วันทูคอล </p> <a href="download/Eagle vpn.apk" class="btn btn-primary"> <i class="fa fa-download" aria-hidden="true"></i> download</a> 

</div> 
</div>

<br>
<div class="card" style="width: 19rem;"> <img src="img/tikvpn.png" class="card-img-top"
 alt="auto"> <div class="card-body"> <h5 class="card-title">แอพ TIK VPN 2021</h5> <p class="card-text">แอพสำหรับใช้เล่นเกมส์และโซเชี่ยวต่างๆ เซิร์ฟเวอร์ไทยมีทั้งฟรีเเละเช่าสำหรับVIP </p> <a href="download/TIK VPN NETFREE ®.apk.zip" class="btn btn-primary"> <i class="fa fa-download" aria-hidden="true"></i> download</a> 

</div> 
</div>

<br>
<div class="card" style="width: 19rem;"> <img src="img/youtubeven.png" class="card-img-top"
 alt="auto"> <div class="card-body"> <h5 class="card-title">แอพยูทูป venred pro</h5> <p class="card-text">แอพสำหรับใช้ดูยูทูปแบบไม่มีโฆษณา</p> <a href="https://www.vanced.pro/" class="btn btn-primary"> <i class="fa fa-download" aria-hidden="true"></i> download</a> 

</div> 
</div>



