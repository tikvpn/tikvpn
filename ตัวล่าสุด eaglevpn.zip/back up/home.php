<?php
include ("inc_head.php");
?>
<br />
<form action="" class="was-validated"  method="POST">

   <p class="card-text">ยังไม่พร้อมใช้งานน๊ะจ๊ะ  </p>

<p>


<div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text"><i class="fa fa-user"></i> </div>
<input type="hidden" name="credit" value="tikvpn-">
        </div>

       <input type="text" class="form-control text-center is-invalid" name="user" placeholder="ชื่อผู้ใช้เป็นภาษาอังกฤษเท่านั้น..!!" autocomplete="off" required>
      </div>
 <p>

<div class="input-group">
        <div class="input-group-prepend">
          <div class="input-group-text"><i class="fa fa-lock" aria-hidden="true"></i></div>

        </div>

 <input type="password" class="form-control text-center is-invalid" name="pass" id="pass" placeholder="รหัสผ่านเป็นตัวเลขหรือภาษาอังกฤษเท่านั้น..!!" autocomplete="off" required>
      </div>
<p>
<br />

<input type="submit" class="btn btn-success" value="สมัครสมาชิก" name="createButton"/>

</form>


</center>
</div>
</font>
</div>
</div>