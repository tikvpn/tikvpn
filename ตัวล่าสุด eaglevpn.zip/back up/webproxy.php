<?php
include ("inc_head.php");
?>

 <center>
<p class="card-text">เว็บไซต์ hidemy  
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="https://hidemy.name/en/proxy-list/?country=SGTH&type=hs4#list" class="btn btn-Success"> ฟรี</a>
</p>

<br>
<p class="card-text">เว็บไซต์ proxynova.com
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="https://www.proxynova.com/proxy-server-list/country-th/" class="btn btn-Success"> ฟรี</a>
</p>

<br>

<p class="card-text">เว็บไซต์ free proxy  
<i class="fa fa-internet-explorer" aria-hidden="true"></i>
    <a href="http://free-proxy.cz/en/proxylist/country/TH/all/ping/all" class="btn btn-Success"> ฟรี</a>
</p>
  




