<?php

?>
<center>

<div class="card" style="width: 14rem;"> <img src="img/eagle.png" class="card-img-top"
 alt="auto"> <div class="card-body">

<center>
<h5 class="card-title">อัพเดท Eagle VPN 06/09/2021</font></h4>
<font color="#000000">
<h4 class="card-title">ดาวน์โหลดเวอร์ชั่นล่าสุดแล้วติดตั้งทับแอพเก่าได้เลย หากใครติดตั้งไม่ได้ไห้ถอนติดตั้งแอพตัวเก่าออกก่อน</font></h4>
<a href="download/EAGLE VPN.apk" class="btn btn-Success"> Download คลิ๊ก</a>
<p>
</div> 
</div>