package shwelu.shanlayvpn.net;

import android.os.Bundle;
import android.util.Log;
import android.content.SharedPreferences;
import android.content.Context;

public class OpenVPNDisconnect extends OpenVPNClientBase {
    private static final String TAG = "OpenVPNDisconnect";

    public void onCreate(Bundle savedInstanceState) {
		
		if (OpenVPNClientBase.themeSet) {
            setTheme(OpenVPNClientBase.themeResId);
        }

		SharedPreferences sharedPreferences = getSharedPreferences("theme", Context.MODE_PRIVATE);
        setTheme(sharedPreferences.getInt("themeId",OpenVPNClientBase.themeResId));
		
        super.onCreate(savedInstanceState);
        Log.d(TAG, "disconnect");
        submitDisconnectIntent(false);
        finish();
    }
}
