package shwelu.shanlayvpn.net.ads;

import com.google.android.gms.ads.reward.RewardedVideoAd;
import android.content.Context;
import com.google.android.gms.ads.reward.RewardedVideoAdListener;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdRequest;

public class RewardAdAPI implements RewardedVideoAdListener {
	
	private RewardedVideoAd ad;
	private boolean adRewarded;
	private AdListener adListener;

	public RewardAdAPI(Context context) {
		ad = MobileAds.getRewardedVideoAdInstance(context);
		ad.setRewardedVideoAdListener(this);
	}

	@Override
	public void onRewardedVideoAdLoaded() {
		adListener.onAdLoaded();
		ad.show();
	}

	@Override
	public void onRewardedVideoAdOpened() {
	}

	@Override
	public void onRewardedVideoStarted() {
		adRewarded = false;
	}

	@Override
	public void onRewardedVideoAdClosed() {
		if (adRewarded) adListener.onRewarded();
		else adListener.onAdSkipped();
		adRewarded = false;
	}

	@Override
	public void onRewarded(RewardItem p1) {
		adRewarded = true;
	}

	@Override
	public void onRewardedVideoAdLeftApplication() {
	}

	@Override
	public void onRewardedVideoAdFailedToLoad(int errorCode) {
		adRewarded = false;
		adListener.onAdLoaded();
		adListener.onFailedToLoad("Rewarded video Ad failed to load.\nError code : " + errorCode);
	}

	@Override
	public void onRewardedVideoCompleted() {
		adRewarded = true;
	}
	
	public void loadAd(AdListener adListener) {
		this.adListener = adListener;
		ad.loadAd(AdConfig.REWARD_UNIT, new AdRequest.Builder().build());
	}
    
	public interface AdListener {
		void onAdLoaded();
		void onRewarded();
		void onAdSkipped();
		void onFailedToLoad(String message);
	}
}
