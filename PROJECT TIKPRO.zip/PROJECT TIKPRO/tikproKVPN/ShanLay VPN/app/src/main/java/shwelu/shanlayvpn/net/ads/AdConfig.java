package shwelu.shanlayvpn.net.ads;

public class AdConfig {

    public static final String REWARD_UNIT = "ca-app-pub-4391543723393227/4559258460";


}

