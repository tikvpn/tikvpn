package shwelu.shanlayvpn.net.time;
import android.content.Context;
import android.os.CountDownTimer;
import android.widget.TextView;
import android.app.Activity;
import java.util.concurrent.TimeUnit;
import java.util.Locale;
import android.content.Intent;
import shwelu.shanlayvpn.net.OpenVPNService;
import java.text.SimpleDateFormat;
import java.util.Date;
import shwelu.shanlayvpn.net.OpenVPNClient;


public class TimeAPI {
    private Activity activity;
	private TimePref pref;

	private CountDownTimer countDown;
	private TextView tv;

	private long time;

	public TimeAPI(Activity activity) {
		this.activity = activity;
		pref = TimePref.getInstance(activity);

		time = pref.getTime();
	}

	private long getCurrentTime() {
		return System.currentTimeMillis();
	}
	

	public boolean hasValidTime() {
		return getRemainingTime() > 0 || TimeConfig.BONUS_TIME > 0;
	}
	
	public boolean maxTime(){
		
		return getRemainingTime() > 5000 * 60 * 60 * 1000;
	}
	
	public boolean maxNonTime(){

		return getRemainingTime() > 5000 * 60 * 60 * 1000;
	}
	

	private long getRemainingTime() {
		return time - getCurrentTime();
	}

	private long getBonusTime() {
		pref.saveTime(getCurrentTime() + TimeConfig.BONUS_TIME);
		return TimeConfig.BONUS_TIME;
	}

	public void addRewardTime() {
		addRewardTime(TimeConfig.REWARD_TIME, false);
	}

	public void addRewardTime(long reward, boolean ignoreMaxTime) {
		long currentTime = getCurrentTime();
		long baseTime = time < currentTime ? currentTime : time;
	    time = baseTime + reward;
		
		if (!ignoreMaxTime) {
			long idealMaxTime = currentTime + TimeConfig.MAX_REWARD_TIME;
			time = time >= idealMaxTime ? idealMaxTime : time;
		}
		pref.saveTime(time);
	}
	
	public void addNonTime() {
		addRewardTime(TimeConfig.AAD_TIME, false);
	}
	
	public void addNonTime(long reward, boolean ignoreMaxTime) {
		long currentTime = getCurrentTime();
		long baseTime = time < currentTime ? currentTime : time;
	    time = baseTime + reward;

		if (!ignoreMaxTime) {
			long idealMaxTime = currentTime + TimeConfig.MAX_REWARD_TIME;
			time = time >= idealMaxTime ? idealMaxTime : time;
		}
		pref.saveTime(time);
	}

	private String format(long milliseconds) {
		return String.format("%dh %02dm %02ds ",
		                     milliseconds / (3600 * 1000),
							 milliseconds / (60 * 1000) % 60,
							 milliseconds / 1000 % 60, Locale.ENGLISH);	
	}

	public void reset() {
		stop();
		pref.removeTime();
			
	}
	
	
	
	

	public void start(final TextView tv, final TimeoutListener listener) {
		stop();

		long time = getRemainingTime();
		time = time > 0 ? time : getBonusTime();
		this.tv = tv;

		countDown = new CountDownTimer(time, 1000){
			@Override
			public void onTick(long timestamp) {
				tv.setText(format(timestamp));
			}

			@Override
			public void onFinish() {
				countDown = null;
				resetTextView("0:00:00");			
				listener.onLimitReached();
				
			}
		};
		countDown.start();
		startTimeService(time);
	}

	private void resetTextView(String timer_view) {
		if (tv != null) {
			tv.setText(timer_view);
		}
	}
	
	

	public void stop() {
		if (countDown != null) countDown.cancel();
		countDown = null;
		resetTextView("ไม่จำกัดเวลา");
		stopTimeService();
	}

	public boolean isRunning() {
		return countDown != null;
	}

	private void startTimeService(long timestamp) {
		Intent intent = new Intent(activity, TimeService.class);
		intent.putExtra(TimeService.EXTRA_TIME, timestamp);
		activity.startService(intent);
	}

	private void stopTimeService() {
		Intent intent = new Intent(activity, TimeService.class);
		activity.stopService(intent);
	}

	public void stopVpnService() {
		activity.startService(buildDisconnectIntent(activity));
	}

	public static Intent buildDisconnectIntent(Context context) {
        return new Intent(context, OpenVPNService.class).setAction(OpenVPNService.ACTION_DISCONNECT).putExtra(OpenVPNService.INTENT_PREFIX + ".STOP", true);
    }

	public interface TimeoutListener {
		void onLimitReached();
	}
}
