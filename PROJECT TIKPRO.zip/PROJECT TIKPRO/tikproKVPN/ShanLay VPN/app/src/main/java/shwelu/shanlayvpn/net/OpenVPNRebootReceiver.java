package shwelu.shanlayvpn.net;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import shwelu.shanlayvpn.net.OpenVPNClientBase;

public class OpenVPNRebootReceiver extends BroadcastReceiver {
    private static final String TAG = "OpenVPNRebootReceiver";

    public void onReceive(Context context, Intent intent) {
        OpenVPNClientBase.autostart(context);
    }
}
