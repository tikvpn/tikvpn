package shwelu.shanlayvpn.net;
import android.app.Application;
import android.content.Context;
import android.provider.Settings;
import android.support.v7.app.AppCompatDelegate;
import com.google.android.gms.ads.MobileAds;
import shwelu.shanlayvpn.net.crash.CrashHandler;
import android.content.SharedPreferences;


public class OpenVPNApplication extends Application {
    public static Context context;

    public void onCreate() {
        
		if (OpenVPNClientBase.themeSet) {
            setTheme(OpenVPNClientBase.themeResId);
        }

		SharedPreferences sharedPreferences = getSharedPreferences("theme", Context.MODE_PRIVATE);
        setTheme(sharedPreferences.getInt("themeId",OpenVPNClientBase.themeResId));
		
		super.onCreate();
		MobileAds.initialize(this);
        CrashHandler.init(this);
        context = getApplicationContext();
		}
    public static String resString(int res_id) {
        return context.getString(res_id);
    }
}
