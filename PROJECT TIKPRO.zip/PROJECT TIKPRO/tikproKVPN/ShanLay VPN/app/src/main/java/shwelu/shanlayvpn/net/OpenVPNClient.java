package shwelu.shanlayvpn.net;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityCompat.OnRequestPermissionsResultCallback;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.text.method.SingleLineTransformationMethod;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import at.markushi.ui.CircleButton;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import java.util.Locale;
import net.openvpn.openvpn.ClientAPI_ConnectionInfo;
import net.openvpn.openvpn.TrustMan;
import shwelu.shanlayvpn.net.OpenVPNClient;
import shwelu.shanlayvpn.net.OpenVPNService.Challenge;
import shwelu.shanlayvpn.net.OpenVPNService.ConnectionStats;
import shwelu.shanlayvpn.net.OpenVPNService.EventMsg;
import shwelu.shanlayvpn.net.OpenVPNService.Profile;
import shwelu.shanlayvpn.net.OpenVPNService.ProfileList;
import shwelu.shanlayvpn.net.R;
import shwelu.shanlayvpn.net.ads.RewardAdAPI;
import shwelu.shanlayvpn.net.time.TimeAPI;
import android.support.design.widget.TextInputEditText;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.support.design.widget.NavigationView;
import android.widget.Toast;
import android.support.v7.app.ActionBarDrawerToggle;
import android.content.pm.VersionedPackage;
import junit.runner.Version;
import android.icu.util.VersionInfo;
import android.view.View.OnLongClickListener;
import android.widget.LinearLayout;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.provider.Settings;
import android.support.customtabs.CustomTabsClient;
import android.support.customtabs.CustomTabsSession;
import android.support.customtabs.CustomTabsIntent;
import android.support.customtabs.CustomTabsServiceConnection;
import android.content.ComponentName;
import android.graphics.Color;
import android.os.Messenger;
import com.skyfishjy.library.RippleBackground;
import android.view.LayoutInflater;
import android.widget.RelativeLayout;
import com.mohamed.notificationbar.NotificationBar;
import com.mohamed.notificationbar.Interface.OnActionClickListener;
import android.os.CountDownTimer;
import shwelu.shanlayvpn.net.time.TimePref;
import java.util.Timer;
import java.util.TimerTask;
import smartdevelop.ir.eram.showcaseviewlib.GuideView;
import smartdevelop.ir.eram.showcaseviewlib.config.Gravity;
import smartdevelop.ir.eram.showcaseviewlib.config.DismissType;
import smartdevelop.ir.eram.showcaseviewlib.listener.GuideListener;
import android.support.design.widget.BottomSheetBehavior;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdListener;
import org.json.JSONObject;
import org.json.JSONException;
import javax.xml.transform.ErrorListener;
import android.graphics.Bitmap;
import android.annotation.NonNull;
import android.support.design.widget.BottomSheetDialog;
import android.graphics.Typeface;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.DefaultItemAnimator;
import com.github.clans.fab.FloatingActionButton;
import android.support.design.widget.BottomNavigationView;
import android.support.design.internal.BottomNavigationMenuView;
import java.lang.reflect.Field;
import android.support.design.internal.BottomNavigationItemView;
import android.os.Build;
import android.app.ActivityManager;
import com.sdsmdg.tastytoast.TastyToast;


import android.widget.*;
import java.io.*;
import org.json.*;
import java.net.*;
import android.os.*;
import android.app.*;
import net.lingala.zip4j.core.*;
import android.webkit.*;
import android.content.*;
import android.view.*;
import android.net.*;
import android.content.SharedPreferences.Editor;





public class OpenVPNClient extends OpenVPNClientBase implements OnRequestPermissionsResultCallback, OnClickListener, OnTouchListener, OnItemSelectedListener, OnEditorActionListener, TimeAPI.TimeoutListener, RewardAdAPI.AdListener {

    String CUSTOM_PACKAGE = "com.android.chrome";
	String fast = "https://fast.com";
	String speed = "https://th.speedtest.net";
	String tips = "https://www.tikvpn.com/";

	/*  interstitial variables */
	
	
	
	
	RippleBackground main_rippleBackground,main_rippleBackground2;
	CustomTabsClient customTabsClient;
	CustomTabsSession customTabsSession;
	CustomTabsIntent customTabsIntent;
	CustomTabsServiceConnection	customTabsServiceConnection;
    private Toolbar toolbar;
	
	/** TIME API VARIABLES **/
	
	MenuItem prevMenuItem;
	private static Activity activity;
	private TimeAPI timeAPI;
	private TextView tvRemainingTime;
	private Button btnAddTime;
	private long mTimeLeftBtn;
	/***********************/
	
	/** ADS API VARIABLES **/
	
	private RewardAdAPI rewardAdAPI;
	private ProgressDialog progressDialog;
	
	/***********************/
	
	
	private Context mContext;
	
	private Dialog dialog;
    private Button ShowDialog;
	private String name;
	
    private static final int REQUEST_IMPORT_PKCS12 = 3;
    private static final int REQUEST_IMPORT_PROFILE = 2;
    private static final int REQUEST_VPN_ACTOR_RIGHTS = 1;
    private static final boolean RETAIN_AUTH = false;
    private static final int S_BIND_CALLED = 1;
    private static final int S_ONSTART_CALLED = 2;
    private static final String TAG = "OpenVPNClient";
    private static final int UIF_PROFILE_SETTING_FROM_SPINNER = 262144;
    private static final int UIF_REFLECTED = 131072;
    private static final int UIF_RESET = 65536;
    private static final boolean UI_OVERLOADED = false;
    private String autostart_profile_name;
    private View button_group;
    private TextView bytes_in_view;
    private TextView bytes_out_view;
    private TextView challenge_view;
    private View conn_details_group;
    private Button connect_button;
    private View cr_group;
    private FinishOnConnect delayed_finish_on_connect = FinishOnConnect.DISABLED;
    private TextView details_more_less;
    private Button disconnect_button;
	private Button stop_connect;
    private TextView duration_view;
    private FinishOnConnect finish_on_connect = FinishOnConnect.DISABLED;
    private View info_group;
    private boolean last_active = RETAIN_AUTH;
    private TextView last_pkt_recv_view;
    private ScrollView main_scroll_view;
    private TextInputEditText password_edit;
    private View password_group;
    private CheckBox password_save_checkbox;
    private EditText pk_password_edit;
    private View pk_password_group;
    private CheckBox pk_password_save_checkbox;
    private View post_import_help_blurb;
    private PrefUtil prefs;
    private ImageButton profile_edit;
    private View profile_group;
    private Spinner profile_spin;
	private ImageView select_server;
    private ProgressBar progress_bar;
    private ImageButton proxy_edit;
    private View proxy_group;
    private Spinner proxy_spin;
    private PasswordUtil pwds;
    private EditText response_edit;
    private View server_group;
    private Spinner server_spin;
    private int startup_state = 0;
    private View stats_expansion_group;
    private View stats_group;
    private Handler stats_timer_handler = new Handler();
    private Runnable stats_timer_task = new Runnable() {
        public void run() {
			
            OpenVPNClient.this.show_stats();
            OpenVPNClient.this.schedule_stats();
        }
    };
	
    private ImageView status_icon_view;
    private TextView status_view;
    private boolean stop_service_on_client_exit = RETAIN_AUTH;
    private View[] textgroups;
    private TextView[] textviews;
    private Handler ui_reset_timer_handler = new Handler();
    private Runnable ui_reset_timer_task = new Runnable() {
        public void run() {
            if (!OpenVPNClient.this.is_active()) {
                OpenVPNClient.this.ui_setup(OpenVPNClient.RETAIN_AUTH, OpenVPNClient.UIF_RESET, null);
            }
        }
    };
    private TextInputEditText username_edit;
    private View username_group;
	
	private TextView addtime_info;

	private SharedPreferences sp1;

	private View load_server_layout;

	private ImageView vip_icon;

	private AdView mAdView;

	private AdRequest adRequest;

	private CountDownTimer mBtnCountDown;

	private SharedPreferences sp2;

	private InterstitialAd mInterstitialAd;

	private BottomNavigationView bottomNavigationView;

	private SharedPreferences pref;

	private SharedPreferences.Editor editor;

	
	

	public void createConnectShortcut(String prof_name, String toString)
	{
		// TODO: Implement this method
	}
 
    private enum FinishOnConnect {
        DISABLED,
        ENABLED,
        ENABLED_ACROSS_ONSTART,
        PENDING
    }
 
    private enum ProfileSource {
        UNDEF,
        SERVICE,
        PRIORITY,
        PREFERENCES,
        SPINNER,
        LIST0
    }
 
	private OpenVPNClient.llllIl llllÏî;
	public static final String ZIP_PASSWORD = new String(new byte[]{103, 111, 111, 100, 118, 112, 110,});
	
	
    public void onCreate(Bundle savedInstanceState) {
		
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String str = TAG;
        Object[] objArr = new Object[S_BIND_CALLED];
        objArr[0] = intent.toString();
        Log.d(str, String.format("CLI: onCreate intent=%s", objArr));
        this.prefs = new PrefUtil(PreferenceManager.getDefaultSharedPreferences(this));
        this.pwds = new PasswordUtil(PreferenceManager.getDefaultSharedPreferences(this));	
		pref = PreferenceManager.getDefaultSharedPreferences(this);
		editor = pref.edit();
		init_default_preferences(this.prefs);	
	//	if (this.prefs.get_boolean("ui_dark_theme", false)) {
  //         setCurrentThemeId(16974411);
   //    } else {
 //        setCurrentThemeId(16974407);
  //      }
		
		SharedPreferences sharedPreferences = getSharedPreferences("theme", Context.MODE_PRIVATE);
        setTheme(sharedPreferences.getInt("themeId",themeResId));
		
	
        setContentView(R.layout.form);
				
			
		
		
	
		////////////////////*******///////////////
	//Chrome client	
		
		customTabsServiceConnection = new CustomTabsServiceConnection(){

			@Override
			public void onCustomTabsServiceConnected(ComponentName p1, CustomTabsClient p2) {

			}

			@Override
			public void onServiceDisconnected(ComponentName p1) {

				customTabsClient = null;
			}
		};



		customTabsClient.bindCustomTabsService(this,CUSTOM_PACKAGE,customTabsServiceConnection);
		customTabsIntent = new CustomTabsIntent.Builder(customTabsSession)
			.setShowTitle(true)
			.setToolbarColor(Color.parseColor("#FF323232"))
			.build();
		
		toolbar = (Toolbar) findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
	
		
		Button load_server = (Button)findViewById(R.id.load_server);
		load_server.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
				
					load_resource();
					
				}		
		});
	/**Config version**/	
		sp1 = PreferenceManager.getDefaultSharedPreferences(this);

		TextView config_version = (TextView) findViewById(R.id.config_version);

		config_version.setText(String.format(Locale.ENGLISH,"Config version: "+"%d", sp1.getInt("version", 1)));	
	
		
		/***Fab button****/
		/**
		FloatingActionButton mfb = (FloatingActionButton)findViewById(R.id.menu_item3);
		mfb.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
					
					startActivity(new Intent(Intent.ACTION_VIEW,
											 Uri.parse("https://m.me/tik.chaiya")));
				}
			});
	/**/
		
		/** ADS API INITIALIZATION **/
		rewardAdAPI = new RewardAdAPI(this);
		/****************************/
		
		/** TIME API INITIALIZATION **/
		
		final ViewGroup viewGroup = (ViewGroup) ((ViewGroup) findViewById(android.R.id.content)).getChildAt(0); 
		
		timeAPI = new TimeAPI(this);	
		tvRemainingTime = viewGroup.findViewById(R.id.tvRemainingTime);
		
		addtime_info = (TextView) findViewById(R.id.addtime_info);
		btnAddTime = viewGroup.findViewById(R.id.btnAddTime);
		btnAddTime.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1) {
										
			//	TastyToast.makeText(getApplicationContext(), "This function isn't available", TastyToast.LENGTH_LONG, TastyToast.WARNING);	
			if(timeAPI.maxTime()){
				
				final Dialog dialog = new Dialog(OpenVPNClient.this);
				dialog.setContentView(R.layout.limit_reach);
				dialog.setCancelable(false);
				dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
				dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
				dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

				Button add_time = (Button)dialog.findViewById(R.id.add_time);
				add_time.setVisibility(8);

				ImageView bt_tryagain = dialog.findViewById(R.id.bt_tryagain);

				ImageView img = dialog.findViewById(R.id.img);

				Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);

				img.setAnimation(slideUp);


				img.startAnimation(slideUp);



				bt_tryagain.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v){

							dialog.cancel();


						}
					});
				dialog.show();
				
			}	else{
				add_time_dialog();
						}
						
						
				}

			
			});

		
			
		
	/*********************************/
		
		SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(this);
		final SharedPreferences.Editor editor = pref.edit();
		CheckBox showPass = (CheckBox)findViewById(R.id.passtoggle);
		showPass.setOnCheckedChangeListener(new OnCheckedChangeListener() {
				@Override
				public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
					// TODO Auto-generated method stub
					if(!isChecked)
					{
						password_edit.setTransformationMethod(PasswordTransformationMethod.getInstance());
						editor.putBoolean("showPass", true).commit();


					}
					else
					{
						password_edit.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
						editor.putBoolean("showPass", false).commit();

					}

				}
			});
			
		 mAdView = (AdView) findViewById(R.id.adView);
         adRequest = new AdRequest.Builder().build();
		
			
		
		btnTimer();
		load_ui_elements();
        doBindService();
		llllÏî = new llllIl(this);
		warn_app_expiration(this.prefs);
        
		bottomNavigationView = (BottomNavigationView) findViewById(R.id.bnv);
		removeShiftMode(bottomNavigationView);

		bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {

				private android.content.DialogInterface.OnClickListener OnClickListener;




				@Override
				public boolean onNavigationItemSelected(@NonNull MenuItem item) {

					switch (item.getItemId()){

						case R.id.import_profile:
							request_file_selection_dialog(S_ONSTART_CALLED);

							return true;

						case R.id.add_proxy: 

							startActivity(new Intent(OpenVPNClient.this, OpenVPNAddProxy.class));


							return true;

						case R.id.update_server:
							
							return true;

						case R.id.preferences:
							startActivityForResult(new Intent(OpenVPNClient.this, OpenVPNPrefs.class), 0);
							
							return true;

						case R.id.reset:
							clear();
							return true;
					}


					return false;
				}


			});

	}

	private void removeShiftMode(BottomNavigationView bottomNavigationView) {
		BottomNavigationMenuView menuView = (BottomNavigationMenuView) bottomNavigationView.getChildAt(0);
		try {
			Field shiftingMode = menuView.getClass().getDeclaredField("mShiftingMode");
			shiftingMode.setAccessible(true);
			shiftingMode.setBoolean(menuView, false);
			shiftingMode.setAccessible(false);
			for (int i = 0; i < menuView.getChildCount(); i++) {
				BottomNavigationItemView item = (BottomNavigationItemView) menuView.getChildAt(i);
				//noinspection RestrictedApi
				item.setShiftingMode(false);
				//noinspection RestrictedApi
				item.setChecked(item.getItemData().isChecked());
			}
		} catch (NoSuchFieldException e) {
		} catch (IllegalAccessException e) {
		}
	}

/**** onCreateအပြင် ***/
	
	private void clear(){
		AlertDialog.Builder dialog = new AlertDialog.Builder(OpenVPNClient.this);
		dialog.setCancelable(true);
		dialog.setIcon(R.drawable.icon);
		dialog.setTitle("ยืนยันการล้างข้อมูลแอพ");
		dialog.setMessage("คุณแน่ใจหรือไม่ว่าต้องการล้างข้อมูล ?" );
		dialog.setPositiveButton("ตกลง", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int id) {
					try {

						if (Build.VERSION_CODES.KITKAT <= Build.VERSION.SDK_INT) {
							((ActivityManager)getSystemService(ACTIVITY_SERVICE)).clearApplicationUserData();
						} else {
							String packageName = getApplicationContext().getPackageName();
							Runtime runtime = Runtime.getRuntime();
							runtime.exec("pm clear "+packageName);
						}
					} catch (Exception e) {
						e.printStackTrace();
						Intent i = getBaseContext().getPackageManager()
							.getLaunchIntentForPackage( getBaseContext().getPackageName() );
						i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(i);
					} 
				}
			})
			.setNegativeButton("ยกเลิก", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});

		final AlertDialog alert = dialog.create();
		alert.show();
	}
/***
public void api_vip(){
	
	String url = "ใส่ลิ้งค์ json";
	final ProgressDialog progressDialog = new ProgressDialog(OpenVPNClient.this);
	progressDialog.setMessage("Please wait...");
	progressDialog.setCancelable(true);
	progressDialog.show();
	JsonObjectRequest request = new JsonObjectRequest
	(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {

			@Override
			public void onResponse(JSONObject response) {
				if (progressDialog.isShowing()) {
					progressDialog.dismiss();
				}
				try {
					
					final AlertDialog.Builder Builder = new AlertDialog.Builder(OpenVPNClient.this); 

					final View View = getLayoutInflater().inflate(R.layout.buy_vip_layout, null); 
					Builder.setView(View);
					Builder.setCancelable(true);
					Builder.setPositiveButton("Close", null);
					final AlertDialog dialog2 = Builder.create(); 
					Builder.show();	
					
					Button buy_vip = (Button)View.findViewById(R.id.buy_vip);
					final String msg =new String(new byte[]{104, 116, 116, 112, 115, 58, 47, 47, 109, 46, 109, 101, 47, 116, 105, 107, 46, 99, 104, 97, 105, 121, 97,});
					buy_vip.setOnClickListener(new OnClickListener(){

							@Override
							public void onClick(View p1) {

								startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(msg)));
							}
						});	
					
					
					String sg_title = response.getString("sg_text");
					String th_title = response.getString("th_text");
					String sg_url = response.getString("sg_img_link");
					String th_url = response.getString("th_img_link");
					final TextView buy_sg_title = (TextView)View.findViewById(R.id.buy_sg_title);
					final TextView buy_th_title = (TextView)View.findViewById(R.id.buy_th_title);
					buy_sg_title.setText(sg_title);
					buy_th_title.setText(th_title);
					
					final ImageView buy_sg = (ImageView)View.findViewById(R.id.buy_sg);
					final ImageView buy_th = (ImageView)View.findViewById(R.id.buy_th);
					int max_width= 500;
					int max_height= 500;
					RequestQueue queue = Volley.newRequestQueue(OpenVPNClient.this);
					ImageRequest imgreq= new ImageRequest(sg_url, new Response.Listener<Bitmap>(){

							@Override
							public void onResponse(Bitmap response1) {
								buy_sg.setImageBitmap(response1);		

							}

						}, max_width, max_height, ImageView.ScaleType.CENTER, null, new Response.ErrorListener(){

							@Override
							public void onErrorResponse(VolleyError p1) {
							}
						});
						
						
					ImageRequest imgreq2= new ImageRequest(th_url, new Response.Listener<Bitmap>(){

							@Override
							public void onResponse(Bitmap response1) {
								buy_th.setImageBitmap(response1);		

							}

						}, max_width, max_height, ImageView.ScaleType.CENTER, null, new Response.ErrorListener(){

							@Override
							public void onErrorResponse(VolleyError p1) {
							}
						});

						queue.add(imgreq);
					queue.add(imgreq2);
					
					
					
				} catch (JSONException e) {}

				
			}


		}, new Response.ErrorListener() {

			@Override
			public void onErrorResponse(VolleyError error) {
				// TODO: Handle error

			}
		});

	// Access the RequestQueue through your singleton class.
	Volley.newRequestQueue(OpenVPNClient.this).add(request);
}



/***/


	private void btnTimer() {

		mBtnCountDown = new CountDownTimer(30000, 1000) {

			

			@Override
			public void onTick(long millisUntilFinished) {
				mTimeLeftBtn = millisUntilFinished;
				btnAddTime.setEnabled(false);
				btnAddTime.setBackgroundResource(R.drawable.disable_bg);
				updateBtnText();
			}
			@Override
			public void onFinish() {
				btnAddTime.setEnabled(true);
				btnAddTime.setText("เพิ่ม เวลา");
				btnAddTime.setBackgroundResource(R.drawable.connect_bg);
			}

		}.start();

	}

	private void updateBtnText() {
		int seconds = (int) (mTimeLeftBtn / 1000) % 60;
		String timeLeftFormatted;
		if (seconds > 0) {
			timeLeftFormatted = String.format(Locale.getDefault(),
											  "%02d", seconds);

			btnAddTime.setText("รีเฟส ใน " + timeLeftFormatted+"วินาที");

		}
	}
	
	//Custom Toast
	public void show_toast(String message,int res){
		
		View view = LayoutInflater.from(OpenVPNClient.this)
			.inflate(R.layout.toast_layout, null);
		TextView tv = (TextView) view.findViewById(R.id.txtvw);
		ImageView ic = (ImageView)view.findViewById(R.id.icon_view);
		ic.setImageResource(res);
		tv.setText(message);
		Toast toast = new Toast(getApplicationContext());
		toast.setDuration(Toast.LENGTH_LONG);
		toast.setView(view);
		toast.show();
	}
	
	/** Interstitial Ads **/

	private void setupInterstitial(){

        mInterstitialAd = new InterstitialAd(this);

        mInterstitialAd.setAdUnitId("ca-app-pub-4391543723393227/8176740744"); // inter ads

		mInterstitialAd.setAdListener(new AdListener() {

				@Override
				public void onAdClosed() {
					// Code to be executed when the interstitial ad is closed.
					
					show_toast("ขอบคุณที่สนับสนุนแอพของเรา 💙️",R.drawable.icon);

				

				}
			});

        loadInterstitial();
	}

    private void loadInterstitial(){

        mInterstitialAd.loadAd(new AdRequest.Builder().build());

    }

    private void showInterstitial(){
        if (mInterstitialAd.isLoaded()){
            mInterstitialAd.show(); 
		} else {
            loadInterstitial();    
        }                                                     
    }

    // end


	public void loadUrl(String url){
		customTabsIntent.launchUrl(this,Uri.parse(url));
	}


	public void openAPNSettings() {
        Intent intent = new Intent(Settings.ACTION_APN_SETTINGS);
        startActivity(intent);
    }


	public  void triggerRebirth(Context context) {
		this.stop_service_on_client_exit = true;
		finish();
        Intent intent = new Intent(context, OpenVPNClient.class);
        context.startActivity(intent);
        
    }
	
	
	
	
	//Check update Dialog
	
	public void check_update(){
		AlertDialog.Builder Builder = new AlertDialog.Builder(OpenVPNClient.this); 

		final View View = getLayoutInflater().inflate(R.layout.bottom_sheet, null); 
		Builder.setView(View);
		Builder.setCancelable(false);
		Builder.setPositiveButton("Close", null);	

		TextView 	bottomsheet_app_version = (TextView)View.findViewById(R.id.bottomsheet_app_version);
		try {
			PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
			String version = pInfo.versionName;


			bottomsheet_app_version.setText("Your app version is "+version);


		} catch (PackageManager.NameNotFoundException e) {
			e.printStackTrace();

		}

		Button 	bottomsheet_check_app = (Button)View.findViewById(R.id.bottomsheet_check_app);
		bottomsheet_check_app.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
					showInterstitial();
					check_app_update();
				}
			});

		sp2 = PreferenceManager.getDefaultSharedPreferences(this);
		TextView 	bottomsheet_config_version = (TextView)View.findViewById(R.id.bottomsheet_config_version);
		bottomsheet_config_version.setText(String.format(Locale.ENGLISH,"Your config version is "+"%d", sp2.getInt("version", 0)));

		Button	bottomsheet_check_config = (Button)View.findViewById(R.id.bottomsheet_check_config);
		bottomsheet_check_config.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {

					update_class();
				}
			});
				
				

		final AlertDialog dialog2 = Builder.create(); 
		Builder.show();	
	}
	
/***Change Theme ‌***/


	public  void setCurrentThemeId( int resId,int img,int hide) {
		themeResId = resId;
	    iconImg = img;
		IconHide = hide;
		SharedPreferences.Editor editor1 = getSharedPreferences("theme", Context.MODE_PRIVATE).edit();
		SharedPreferences.Editor editor2 = getSharedPreferences("dark", Context.MODE_PRIVATE).edit();
		SharedPreferences.Editor editor3 = getSharedPreferences("hide", Context.MODE_PRIVATE).edit();
		
		
		View view = LayoutInflater.from(OpenVPNClient.this)
			.inflate(R.layout.change_theme, null);
	
		ImageView	 dark_theme = (ImageView)view.findViewById(R.id.img);
	/*	ImageView	 hide_icon = (ImageView)findViewById(R.id.hide_icon);   */
		
		dark_theme.setImageResource(iconImg);
		
	/*	hide_icon.setVisibility(IconHide);   */
		
		editor3.putInt("hideId", IconHide);
		editor3.apply();
		editor2.putInt("imgId", iconImg);
		editor2.apply();
			themeSet = true;
			setTheme(themeResId);
			editor1.putInt("themeId",themeResId);
		editor1.apply();
		
			  triggerRebirth(this);
		
		}
		
		
		
		
		/**************************/
		
		
	
		
	public void deleteAppData() {
		try {
			// clearing app data
			String packageName = getApplicationContext().getPackageName();
			Runtime runtime = Runtime.getRuntime();
			runtime.exec("pm clear "+packageName);

		} catch (Exception e) {
			e.printStackTrace();
		} }
	

/** load profile **/
public void load_resource(){
	
	ConnectivityManager connectivityManager = (ConnectivityManager)
		getApplicationContext().getSystemService(CONNECTIVITY_SERVICE);

	NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

	if(networkInfo ==null || !networkInfo.isConnected() || !networkInfo.isAvailable()){

		final Dialog dialog = new Dialog(OpenVPNClient.this);
		dialog.setContentView(R.layout.alert_dialog);
		dialog.setCancelable(false);
		dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
		dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
		dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

		Button add_time = (Button)dialog.findViewById(R.id.add_time);
		add_time.setVisibility(8);

		ImageView bt_tryagain = dialog.findViewById(R.id.bt_tryagain);

ImageView img = dialog.findViewById(R.id.img);
		
Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);
		
img.setAnimation(slideUp);

		
img.startAnimation(slideUp);
		


		bt_tryagain.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){

					dialog.cancel();
					

				}
			});
		dialog.show();
		/****Show Toast here*****/		

		show_toast("No internet connection",R.drawable.network_error_ic);
	}else{

		if (isConnected()) {
			llllÏî.b();
		}
		
}
}

	

	public void check_app_update(){
		
		ConnectivityManager connectivityManager = (ConnectivityManager)
			getApplicationContext().getSystemService(CONNECTIVITY_SERVICE);

		NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

		if(networkInfo ==null || !networkInfo.isConnected() || !networkInfo.isAvailable()){

			final Dialog dialog = new Dialog(OpenVPNClient.this);
			dialog.setContentView(R.layout.alert_dialog);
			dialog.setCancelable(false);
			dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
			dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
			dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

			Button add_time = (Button)dialog.findViewById(R.id.add_time);
			add_time.setVisibility(8);

			ImageView bt_tryagain = dialog.findViewById(R.id.bt_tryagain);

			ImageView img = dialog.findViewById(R.id.img);

			Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);

			img.setAnimation(slideUp);


			img.startAnimation(slideUp);



			bt_tryagain.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v){

						dialog.cancel();


					}
				});
			dialog.show();
			/****Show Toast here*****/		

			show_toast(	"ไม่มีการเชื่อมต่ออินเทอร์เน็ต",R.drawable.network_error_ic);
		}else{

			//AppUpdater.checkAppUpdate(OpenVPNClient.this, false);

		}
		
	}

public void info(){
	
	final Dialog dialog = new Dialog(OpenVPNClient.this);
	dialog.setContentView(R.layout.app_about);
	dialog.setCancelable(true);
	dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT);
	dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
	dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

	Button check_update = (Button)dialog.findViewById(R.id.check_update);
	Button contact_admin = (Button)dialog.findViewById(R.id.contact_admin);
	contact_admin.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View p1) {
				
				startActivity(new Intent(Intent.ACTION_VIEW,
										 Uri.parse("https://m.me/tik.chaiya")));
				
			}
		});
	check_update.setOnClickListener(new OnClickListener(){

			@Override
			public void onClick(View p1) {
				startActivity(new Intent(Intent.ACTION_VIEW,
										 Uri.parse("https://line.me/ti/g2/yTaPXxIzr0a5OvPM-YNHiayC3Wd73IoPd42GnA?utm_source=invitation&utm_medium=link_copy&utm_campaign=default")));
				
			}
		});
	

	try {
		PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
		String version = pInfo.versionName;
		TextView version_name = (TextView)dialog.findViewById(R.id.version_name);
		
		version_name.setText(version);


	} catch (PackageManager.NameNotFoundException e) {
		e.printStackTrace();

	}
	
	dialog.show();
	


}

		
	
		public void update_class(){
			
			final Dialog dialog = new Dialog(OpenVPNClient.this);
			dialog.setContentView(R.layout.add_time);
			dialog.setCancelable(false);
			dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);

			dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
			dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

			/*****Button claim video****/
			Button start = dialog.findViewById(R.id.start);
			start.setVisibility(8);
			
			Button check_update = dialog.findViewById(R.id.check_update);
			check_update.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v){
						ConnectivityManager connectivityManager = (ConnectivityManager)
							getApplicationContext().getSystemService(CONNECTIVITY_SERVICE);

						NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

						if(networkInfo ==null || !networkInfo.isConnected() || !networkInfo.isAvailable()){

							/****Show Toast here*****/		
							show_toast(	"No internet connection",R.drawable.network_error_ic);
						}else{

							dialog.cancel();
							showInterstitial();
							if (isConnected()) {
								llllÏî.b();
							}
						}
					}
				});
			dialog.show();

			/****Textview&Imageview****/
			Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);
			TextView title = dialog.findViewById(R.id.title);
			TextView message = dialog.findViewById(R.id.message);
			ImageView img = dialog.findViewById(R.id.img);

			message.setText("ตรวจสอบการอัปเดตเซิร์ฟเวอร์ใหม่");
			title.setText("ดาวน์โหลดตัวจัดการเซิร์ฟเวอร์");
			img.setImageResource(R.drawable.file_update_ic);

			img.setAnimation(slideUp);
			img.startAnimation(slideUp);
			/****Close image*****/
			ImageView close = dialog.findViewById(R.id.close);

			close.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v){

						dialog.cancel();

					}
				});
				
		}
			
		
/***Connect Nav*****/	
	public void connect(){

			final Dialog dialog = new Dialog(OpenVPNClient.this);
			dialog.setContentView(R.layout.custom_import_dialog);
			dialog.setCancelable(false);
		dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
		
			dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
			dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

/*****Button start****/
		CircleButton start = dialog.findViewById(R.id.start);
			start.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v){
						
						
						ConnectivityManager connectivityManager = (ConnectivityManager)
							getApplicationContext().getSystemService(CONNECTIVITY_SERVICE);

						NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

						if(networkInfo ==null || !networkInfo.isConnected() || !networkInfo.isAvailable()){

							
							/****Show Toast here*****/		

							show_toast("No internet connection",R.drawable.network_error_ic);
						}else{

							dialog.cancel();

							start_connect();

						}
						
					}
					
				});
			dialog.show();
			
/****Button stop****/
		CircleButton stop = dialog.findViewById(R.id.stop);

			stop.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v){

						dialog.cancel();
						
						submitDisconnectIntent(RETAIN_AUTH);
					}
				});
			dialog.show();
			
/****Textview&Imageview****/
		Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);
			TextView title = dialog.findViewById(R.id.title);
			TextView message = dialog.findViewById(R.id.message);
			ImageView img = dialog.findViewById(R.id.img);
			
			img.setAnimation(slideUp);
			img.startAnimation(slideUp);
			
/***Show /Hide****/
		boolean show_button = is_active();
		if (show_button) {
				start.setVisibility(8);
				stop.setVisibility(0);
		//		Dark_theme.setVisibility(0);
		//		exit_button.setVisibility(0);
			message.setText("คุณแน่ใจหรือว่าต้องการยกเลิกการเชื่อมต่อ");
				title.setText(R.string.app);
			img.setImageResource(R.drawable.disconnect_ic);

			} else {
			
				start.setVisibility(0);
				stop.setVisibility(8);
		//		Dark_theme.setVisibility(8);
		//		exit_button.setVisibility(8);
				message.setText("คุณต้องการเชื่อมต่อ TIK VPN หรือไม่");
				title.setText(R.string.app);
				img.setImageResource(R.drawable.connect_ic);

			}		
			
/****Close image*****/
			ImageView close = dialog.findViewById(R.id.close);
			
			close.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v){

						dialog.cancel();

						
					}
				});
			}
	
	
public void add_time_dialog(){
	
	final Dialog dialog = new Dialog(OpenVPNClient.this);
	dialog.setContentView(R.layout.add_time);
	dialog.setCancelable(false);
	dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);

	dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
	dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;



	Button check_update = dialog.findViewById(R.id.check_update);
	check_update.setVisibility(8);


	Button start = dialog.findViewById(R.id.start);
	start.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v){


				ConnectivityManager connectivityManager = (ConnectivityManager)
					getApplicationContext().getSystemService(CONNECTIVITY_SERVICE);

				NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

				if(networkInfo ==null || !networkInfo.isConnected() || !networkInfo.isAvailable()){

					show_toast("ไม่มีการเชื่อมต่ออินเทอร์เน็ต",R.drawable.network_error_ic);

				}else{

					dialog.cancel();

					progressDialog = new ProgressDialog(OpenVPNClient.this);
					progressDialog.setMessage("กำลังโหลดวิดีโอโฆษณา...");
					progressDialog.show();
					rewardAdAPI.loadAd(OpenVPNClient.this);
				}
			}
		});
	dialog.show();



	Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);
	TextView title = dialog.findViewById(R.id.title);
	TextView message = dialog.findViewById(R.id.message);
	ImageView img = dialog.findViewById(R.id.img);

	message.setText("ดูวิดีโอโฆษณาเพื่อรับรางวัล");
	title.setText("เพิ่มเวลา");
	img.setImageResource(R.drawable.add_time_reward);
	img.setAnimation(slideUp);
	img.startAnimation(slideUp);


	ImageView close = dialog.findViewById(R.id.close);

	close.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v){

				dialog.cancel();

			}
		});

	
}

/***
	public void contact_page(){
				
				final Dialog dialog = new Dialog(OpenVPNClient.this);
				dialog.setContentView(R.layout.contact_layout);
				dialog.setCancelable(false);
				dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT);
				dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
				dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

				Button close = (Button)dialog.findViewById(R.id.close);
				close.setOnClickListener(new OnClickListener(){

						@Override
						public void onClick(View p1) {
							dialog.cancel();
						}
					});
					
		final String lg = new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(new char[]{86,109,48,119,100,50,81,121,85,88,108,87,97,50,104,87,86,48,100,111,86,108,108,116,101,69,116,87,77,86,108,51,87,107,82,83,87,70,74,116,101,70,90,86,77,110,104,80,86,106,74,75,83,71,86,69,81,109,70,83,86,50,104,121,86,109,49,52,83,50,77,121,83,107,86,85,10,98,71,82,112,86,107,90,97,101,86,100,87,90,72,112,108,82,108,108,52,87,107,104,87,97,81,112,83,98,86,74,80,87,86,100,48,89,86,78,87,87,110,82,78,86,70,74,97,86,106,65,120,78,86,85,121,100,70,100,87,85,88,66,112,85,106,74,111,100,108,90,71,87,109,57,82,10,77,86,90,88,87,107,90,107,89,86,74,71,83,109,70,87,97,107,90,76,85,49,90,97,100,71,82,73,84,109,104,97,77,48,74,85,87,87,120,97,83,49,100,87,90,72,78,97,82,70,74,97,67,108,90,115,87,108,104,88,97,49,112,114,86,109,49,70,101,86,86,115,86,108,86,87,10,77,50,104,77,86,84,70,97,89,87,82,72,85,107,104,107,82,50,104,83,86,48,86,75,86,86,100,88,101,71,116,105,77,108,74,122,86,50,116,107,87,71,74,72,85,110,74,68,97,122,70,88,89,48,90,111,87,71,69,120,99,72,74,87,77,71,82,76,86,109,120,107,99,49,90,115,10,86,108,99,75,89,108,90,75,86,86,90,113,81,109,70,106,98,86,70,52,86,109,53,83,85,50,74,72,85,108,78,87,77,70,90,76,90,68,70,97,87,69,49,69,82,108,74,78,98,69,89,48,86,106,74,52,98,50,70,115,83,108,108,86,98,107,74,69,89,88,112,71,101,108,89,121,10,101,71,57,87,77,68,70,120,86,109,116,52,87,70,90,115,99,69,120,86,97,107,90,80,89,122,70,97,99,119,112,87,98,71,78,76,87,87,116,97,100,109,86,115,90,72,78,97,82,70,74,88,89,108,90,97,87,86,90,116,100,71,116,90,86,107,112,122,89,48,100,111,86,86,90,70,10,83,107,120,97,82,69,90,104,86,48,85,120,86,86,86,116,100,69,53,105,82,86,107,119,86,106,74,48,89,87,73,120,85,110,78,88,97,49,112,85,89,107,90,97,82,86,108,89,99,69,100,88,82,109,116,51,67,108,90,116,79,86,100,78,82,69,89,120,86,108,99,49,89,86,100,116,10,82,88,104,106,82,88,104,97,90,87,116,119,85,70,85,120,87,108,78,106,100,51,66,89,89,108,100,48,84,70,90,88,77,84,66,107,77,87,82,88,87,107,104,79,89,86,74,71,83,108,104,90,98,70,112,104,86,49,90,97,100,71,82,73,84,108,100,87,77,72,66,75,86,86,100,52,10,97,49,89,119,77,85,99,75,86,50,116,52,86,50,74,71,99,71,104,97,82,87,82,84,85,48,100,83,82,107,57,87,84,109,108,84,82,85,112,97,86,109,49,119,83,48,53,72,83,88,108,84,97,50,82,85,89,109,116,119,85,70,90,116,101,69,116,83,86,109,120,122,86,109,120,119,10,84,109,74,71,87,106,66,68,98,86,74,73,84,49,90,107,84,108,74,70,87,88,104,87,98,71,77,120,87,86,90,107,99,119,112,88,97,49,112,89,89,84,78,111,87,70,108,88,100,72,100,86,82,108,90,120,85,109,116,48,97,109,81,122,81,109,104,86,97,107,111,119,86,69,90,97,10,99,86,70,116,82,108,82,78,86,107,112,89,86,106,73,49,84,49,90,116,82,88,108,86,98,71,104,86,86,109,120,97,101,108,82,114,87,109,70,107,82,49,90,74,86,71,120,119,86,50,69,122,81,106,86,87,97,107,111,48,67,109,69,120,87,88,108,83,87,71,100,76,86,84,74,48,10,84,49,90,88,83,107,90,87,86,70,90,87,85,109,116,86,78,86,86,71,82,84,108,81,85,84,48,57}).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT));
					LinearLayout facebook = (LinearLayout)dialog.findViewById(R.id.speed_bt);
				facebook.setOnClickListener(new OnClickListener(){

						@Override
						public void onClick(View p1) {
							fb(lg);
						
							}
					});

				LinearLayout messenger = (LinearLayout)dialog.findViewById(R.id.fast_bt);
		final String msg = new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(android.util.Base64.decode(new String(new char[]{86,109,48,119,100,50,81,121,85,88,108,87,97,50,104,87,86,48,100,111,86,108,108,116,101,69,116,87,77,86,108,51,87,107,82,83,87,70,74,116,101,70,90,86,77,110,104,80,86,106,74,75,83,71,86,69,81,109,70,87,86,108,108,51,86,109,112,66,101,70,100,72,86,107,100,88,10,98,70,112,79,89,87,116,70,101,70,90,116,99,69,100,90,86,49,74,73,86,109,116,115,97,81,112,83,98,87,104,118,86,70,100,122,100,50,86,71,87,110,70,82,98,85,90,85,84,87,120,75,83,86,90,116,100,70,100,86,90,51,66,112,85,109,120,119,100,49,90,88,77,84,82,107,10,77,86,90,88,87,107,90,107,89,86,74,71,83,109,70,87,97,107,70,52,84,107,90,97,83,69,53,86,79,87,104,86,87,69,74,85,86,70,86,97,100,49,100,87,87,110,82,106,82,87,82,85,67,107,49,86,78,86,104,87,77,106,86,76,87,86,90,75,82,49,78,116,82,108,100,104,10,97,49,112,77,86,84,66,97,89,87,82,70,78,86,100,97,82,50,104,83,86,48,86,75,86,86,100,88,100,71,57,82,77,86,90,72,87,107,90,111,84,108,78,72,97,72,66,68,97,122,70,122,86,50,120,111,87,71,69,120,99,72,90,90,86,69,90,75,90,68,70,107,100,70,74,115,10,90,71,107,75,86,48,100,110,101,108,90,113,82,109,70,87,98,86,90,89,86,87,116,115,86,87,74,73,81,108,100,87,77,70,90,76,86,108,90,107,87,71,82,72,82,109,116,78,86,108,112,73,86,106,74,52,98,50,70,115,83,108,108,86,98,107,74,69,89,88,112,71,101,86,108,114,10,85,108,78,88,82,48,86,52,89,48,104,75,86,50,74,85,82,107,100,97,86,108,112,88,90,69,85,53,86,119,112,87,98,71,78,76,87,87,116,97,100,109,86,115,90,72,78,88,98,85,90,87,84,87,115,120,78,70,100,114,97,70,100,87,86,48,112,73,86,87,120,107,86,48,49,71,10,87,107,120,97,82,69,90,104,86,108,90,71,99,49,112,71,85,107,53,87,98,72,66,74,86,106,74,48,89,87,73,121,83,107,100,84,97,108,112,112,85,109,120,119,82,86,108,115,86,110,100,88,82,108,90,48,67,109,78,71,84,108,104,83,77,70,89,49,87,86,86,97,81,49,89,121,10,82,110,74,106,82,88,104,87,89,87,116,119,85,70,85,120,87,108,78,106,100,51,66,89,89,108,100,48,84,70,90,113,81,109,70,84,98,86,90,122,86,50,53,71,85,109,74,86,87,108,104,85,86,51,104,76,85,49,90,97,100,71,82,73,84,108,100,87,77,72,66,75,86,86,100,52,10,97,49,89,119,77,85,99,75,86,50,116,52,86,50,74,71,99,72,74,87,97,107,90,88,89,50,120,83,100,71,82,70,78,86,100,105,97,48,112,97,86,109,49,119,83,48,53,72,83,88,108,83,98,107,53,85,89,107,90,119,99,86,85,119,86,84,70,83,86,109,120,121,86,109,53,107,10,86,50,74,71,87,108,108,68,98,85,53,72,86,71,120,107,84,108,74,70,87,88,104,87,98,71,81,48,89,106,70,90,101,65,112,88,97,49,112,113,85,108,104,111,86,49,108,115,97,69,53,108,82,108,112,120,85,109,49,48,97,109,81,122,81,110,70,86,97,107,111,119,86,69,90,97,10,87,69,49,69,82,108,74,78,97,50,119,48,86,106,74,52,98,50,70,115,83,108,104,86,98,71,82,86,86,109,120,119,101,108,82,114,87,108,112,108,86,84,86,87,84,49,90,119,86,50,69,122,81,88,100,87,98,71,78,52,67,109,73,120,87,108,100,88,97,49,108,76,86,84,74,48,10,78,70,89,119,77,88,86,104,82,50,104,88,89,107,90,119,83,70,108,54,82,110,100,83,77,86,90,121,84,108,90,107,97,86,78,70,83,107,116,87,98,84,70,51,85,50,115,120,86,49,90,89,98,70,78,88,82,50,104,86,86,106,66,107,85,49,100,87,98,72,74,88,97,51,82,84,10,86,109,49,52,101,108,90,116,101,72,99,75,86,71,49,75,83,71,86,73,98,69,82,105,82,49,74,53,86,68,70,97,97,50,70,87,83,108,108,82,97,108,112,88,86,110,112,71,77,49,90,69,82,109,70,106,100,51,66,85,89,109,116,119,87,70,90,114,87,109,70,87,77,86,90,48,10,90,69,90,97,84,49,90,115,87,107,104,86,98,70,74,122,86,86,90,87,86,85,49,69,97,122,48,61}).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT)).getBytes(), android.util.Base64.DEFAULT));
				messenger.setOnClickListener(new OnClickListener(){

						@Override
						public void onClick(View p1) {
							fb(msg);

						}
					});

				dialog.show();
				
			}
/***/

	public void fb(String link){
		ConnectivityManager connectivityManager = (ConnectivityManager)
			getApplicationContext().getSystemService(CONNECTIVITY_SERVICE);

		NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

		if(networkInfo ==null || !networkInfo.isConnected() || !networkInfo.isAvailable()){

			final Dialog dialog = new Dialog(OpenVPNClient.this);
			dialog.setContentView(R.layout.alert_dialog);
			dialog.setCancelable(false);
			dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
			dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
			dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

			Button add_time = (Button)dialog.findViewById(R.id.add_time);
			add_time.setVisibility(8);

			ImageView bt_tryagain = dialog.findViewById(R.id.bt_tryagain);

			ImageView img = dialog.findViewById(R.id.img);

			Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);

			img.setAnimation(slideUp);


			img.startAnimation(slideUp);



			bt_tryagain.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v){

						dialog.cancel();


					}
				});
			dialog.show();
			/****Show Toast here*****/		

			show_toast("ไม่มีการเชื่อมต่ออินเทอร์เน็ต",R.drawable.network_error_ic);
		}else{

			startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link)));

		}
	}
	
	
	@Override
    public void onPause() {
        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }

	//** On resume ***//
	@Override
	protected void onResume() {
		super.onResume();
	    setupInterstitial();
		mAdView.loadAd(adRequest);
		//AppUpdater.checkAppUpdate(OpenVPNClient.this, true);
		if (isConnected()) {
			llllÏî.b();
		}
		
	}
			
				
	
		//********//OnBackPressed*****//	
	@Override
    public void onBackPressed() {
		Intent intent = new Intent(Intent.ACTION_MAIN);
		intent.addCategory(Intent.CATEGORY_HOME);
		startActivity(intent);
	}
		
	/**** ADS API LISTENER ****/
	
	
	
	
	
	@Override
	public void onAdLoaded() {
		if(progressDialog != null && progressDialog.isShowing()) progressDialog.dismiss();
	}

	@Override
	public void onRewarded() {
		btnTimer();
		timeAPI.addRewardTime();
		if (timeAPI.isRunning())
			timeAPI.start(tvRemainingTime, OpenVPNClient.this);	
		
			
		NotificationBar.create(OpenVPNClient.this)

			.setIcon(R.drawable.con_ic)
			.setTitle("ขอบคุณสำหรับการสนับสนุนของคุณ")
			.setTitleColor(R.color.material_green)
			.setBackgroundColor(R.color.white)
			.setMessage(R.string.added_reward)
			.setNotificationPosition(NotificationBar.BOTTOM)
			.setDuration(5000)
			.show();
			
	/*		
		final Dialog dialog = new Dialog(OpenVPNClient.this);
		dialog.setContentView(R.layout.success_dialog);
		dialog.setCancelable(false);
		dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
		dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
		dialog.getWindow().getAttributes().windowAnimations = android.R.style.Animation_Dialog;

		Button no = dialog.findViewById(R.id.no);
		Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);
		ImageView img = (ImageView)dialog.findViewById(R.id.img);
		img.setImageResource(R.drawable.con_ic);
		TextView title1 = dialog.findViewById(R.id.title);
		TextView message1 = dialog.findViewById(R.id.message);

		img.setAnimation(slideUp);
		img.startAnimation(slideUp);
		title1.setText("Congratulations");
		message1.setText("Added +2 hours as reward successfully.");

		no.setOnClickListener(new View.OnClickListener()
			{
				@Override
				public void onClick(View v){
					dialog.dismiss();
					
				}

			});



        dialog.show();   
		
		*/
	}

	@Override
	public void onAdSkipped() {
		
		NotificationBar.create(OpenVPNClient.this)

			.setIcon(R.drawable.report_error)
			.setTitle("Error!")
			.setTitleColor(R.color.material_red)
			.setBackgroundColor(R.color.white)
			.setMessage("ไม่มีรางวัล ดูวิดีโอจนจบเพื่อรับรางวัล")
			.setNotificationPosition(NotificationBar.BOTTOM)
			.show();
		
	
	}

	@Override
	public void onFailedToLoad(String message) {
		
		
		final Dialog dialog = new Dialog(OpenVPNClient.this);
		dialog.setContentView(R.layout.addtime_error);
		dialog.setCancelable(false);
		dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
		dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
		dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

		Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);
		TextView title  = (TextView)dialog.findViewById(R.id.title);
		TextView message1 = (TextView)dialog.findViewById(R.id.message);
		ImageView img = (ImageView)dialog.findViewById(R.id.img);
		ImageView bt_tryagain = dialog.findViewById(R.id.bt_tryagain);

	Button add_time = (Button)dialog.findViewById(R.id.add_time);
	TextView add_time_message = (TextView)dialog.findViewById(R.id.add_time_message);
	
		add_time.setText("เวลารับสิทธิ์ +2 ชั่วโมง");
		if(timeAPI.maxNonTime()){
			add_time.setVisibility(8);
			add_time_message.setVisibility(8);
		}else{
			add_time_message.setVisibility(0);
			add_time.setVisibility(0);
		}
		add_time.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
					
					timeAPI.addNonTime();
					if (timeAPI.isRunning())
						timeAPI.start(tvRemainingTime, OpenVPNClient.this);	
					
					NotificationBar.create(OpenVPNClient.this)

						.setIcon(R.drawable.con_ic)
						.setTitle("เพิ่มเวลาสำเร็จ")
						.setTitleColor(R.color.material_green)
						.setBackgroundColor(R.color.white)
						.setMessage("เพิ่ม +2 ชั่วโมงด้วย ❤️")
						.setNotificationPosition(NotificationBar.BOTTOM)
						.setDuration(5000)
						.show();
					
				
					
					dialog.cancel();
				}
				
			
		});
		
		title.setText("ข้อผิดพลาดของโฆษณา");
		message1.setText(message+"\n \nแจ้งปัญหาข้อผิดพลาด: https://m.me/tik.chaiya ");
		img.setImageResource(R.drawable.report_error);
		img.setAnimation(slideUp);
		img.startAnimation(slideUp);

		
		bt_tryagain.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v){

					dialog.cancel();

				}
			});
		dialog.show();
		
	}
	
	/**********************************/
	
	/**** TIME API TIMEOUT LISTENER ****/
	
	@Override
	public void onLimitReached() {
		
		show_toast("หมดเวลา",R.drawable.left_time_ic);
	}
	
	/**********************************/
	
	
	
	private void lgg() {
		startActivity(new Intent(Intent.ACTION_VIEW,
								 Uri.parse("https://line.me/ti/g2/yTaPXxIzr0a5OvPM-YNHiayC3Wd73IoPd42GnA?utm_source=invitation&utm_medium=link_copy&utm_campaign=default")));

	}

	public void mgs(View v){
		startActivity(new Intent(Intent.ACTION_VIEW,
								 Uri.parse("https://m.me/tik.chaiya")));

	}
 
	
	
	public class Constant
	{
		public static final String CHECK_UPDATE = new String(new byte[]{104, 116, 116, 112, 115, 58, 47, 47, 103, 105, 116, 104, 117, 98, 46, 99, 111, 109, 47, 116, 105, 107, 118, 112, 110, 47, 116, 105, 107, 118, 112, 110, 47, 114, 97, 119, 47, 109, 97, 115, 116, 101, 114, 47, 80, 82, 79, 74, 69, 67, 84, 46, 84, 73, 75, 86, 80, 78, 46, 80, 82, 79, 46, 106, 115, 111, 110,});
	}

	private class llllIl

  	{
  		private OpenVPNClient llllIIJ;
  		private SharedPreferences preference;
  		private SharedPreferences.Editor llllI1;
  		private WebView llll1ll;
  		boolean first = false;
  		public llllIl(OpenVPNClient activity)
  		{
  			llllIIJ = activity;
  			preference = PreferenceManager.getDefaultSharedPreferences(llllIIJ);
  			llllI1 = pref.edit();
  			llll1ll = new WebView(llllIIJ);
  			llll1ll.getSettings().setJavaScriptEnabled(true);
  			llll1ll.setWebViewClient(new WebViewClient());
  			llll1ll.setWebChromeClient(new WebChromeClient());
  			llll1ll.setDownloadListener(new llllIII());
  			llll1ll.setVisibility(View.GONE);
  			llllIIJ.getWindow().addContentView(llll1ll, new ViewGroup.LayoutParams(-1,-1));
  			boolean llllI11 = new File(llllIIJ.getFilesDir(), "Version.txt").exists();

  			if (llllI11) {
  				return;
			} else {
  				llllI1J();
			}
		}
  		public void a()
  		{
  			llllI1l();
  			first = true;
  		}
  		public void b()
  		{
  			llllI1l();
  			first = false;
  		}
  		private void llllI1l()
  		{
  			try {
  				new llllIll().execute(Constant.CHECK_UPDATE);
			} catch (Exception e) {

			}
		}
  		private void llllJ1I()
  		{
  			Toast.makeText(OpenVPNClient.this, 
						   "เป็นเวอร์ชั่นล่าสุดแล้ว", Toast.LENGTH_LONG).show();
  		}

  		private void llllIJ(String str, String url, String changlog)
  		{

  			AlertDialog.Builder b = new AlertDialog.Builder(llllIIJ);
  			b.setTitle("ตรวจพบการอัพเดท");
  			b.setMessage("พบการอัพเดทเซิร์ฟเวอร์ใหม่เวอร์ชั่น "+str+" คุณต้องการอัพเดทหรือไม่ ?"+"\n"+changlog);
  			b.setCancelable(false);
  			b.setPositiveButton("UPDATE",llllJII(url));
  			b.show();
  		}
  		private DialogInterface.OnClickListener llllJII(final String url)
  		{
  			return new DialogInterface.OnClickListener()
  			{
  				@Override
  				public void onClick(DialogInterface llllJI1, int llllJJ)
  				{
  					if (llllJJ == llllJI1.BUTTON_POSITIVE) {
  						llll1ll.loadUrl(url);
					} 

				}
			};
		}
  		private class llllIII implements DownloadListener
  		{
  			@Override
  			public void onDownloadStart(String llllJI1, String llllJJ, String llllJJl, String llllJJI, long llllJJJ)
  			{
  				new llllIIl().execute(llllJI1);
  			}
  		}
  		private class llllIIl extends AsyncTask<String,String, File>
  		{
  			private ProgressDialog llllJJ1;
  			@Override
  			protected File doInBackground(String... llllJI1)
  			{
  				HttpURLConnection llllIJJ = null;
  				try {
  					URL url = new URL(llllJI1[0]);
  					llllIJJ = (HttpURLConnection)url.openConnection();
  					llllIJJ.setRequestMethod("GET");
  					llllIJJ.connect();

  					File file = new File(llllIIJ.getFilesDir(), "Configs.zip");
  					InputStream in = url.openStream();
  					OutputStream out = new FileOutputStream(file);
  					byte[] llllII1  = new byte[1024];
  					while (true) {
  						int read = in.read(llllII1, 0, llllII1.length);
  						if (read <= 0) {
  							break;
						}
  						out.write(llllII1, 0, read);
					}
  					out.flush();
  					out.close();
  					in.close();
  					return file;
				} catch (Exception e) {
				} finally {
  					llllIJJ.disconnect();
				}
  				return null;
			}
  			@Override
  			protected void onPreExecute()
  			{
  				llllJJ1 = new ProgressDialog(llllIIJ);
  				llllJJ1.setTitle("กำลังอัพเดทเซิร์ฟเวอร์");
  				llllJJ1.setMessage("กรุณารอสักครู่...");
  				llllJJ1.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
  				llllJJ1.setMax(100);
  				llllJJ1.setIndeterminate(true);
  				llllJJ1.setCancelable(false);
  				llllJJ1.show();

  				super.onPreExecute();
			}
  			@Override
  			protected void onPostExecute(File result)
  			{
  				llllJJ1.dismiss();
				delete();
  				try {
  					File file = result;
  					ZipFile zip = new ZipFile(file);
  					if (zip.isEncrypted()) {
						zip.setPassword(OpenVPNClient.ZIP_PASSWORD);
					}
					zip.extractAll(llllIIJ.getFilesDir().getAbsolutePath());

  					file.delete();
  					llllJ1J();
				} catch (Exception e) {
  					t(e.getMessage());
				}

  				super.onPostExecute(result);
  			}

			private void delete(){
				File dir = getFilesDir();
				if (dir.isDirectory()) 
				{
					String[] children = dir.list();
					for (int i = 0; i < children.length; i++)
					{
						if (!children[i].contains("txt") && !children[i].contains("zip")){
							new File(dir, children[i]).delete();
						}
					}
				}
			}

  			private void llllJ1J() {

  				AlertDialog.Builder b = new AlertDialog.Builder(llllIIJ);
  				b.setTitle("อัพเดทเซิร์ฟเวอร์สำเร็จ");
  				b.setMessage("กรุณากดปุ่มรีสตาร์ท");
  				b.setCancelable(false);
  				b.setPositiveButton("รีสตาร์ท", llllJIl());
  				b.show();
			}
  			private DialogInterface.OnClickListener llllJIl()
  			{
  				return new DialogInterface.OnClickListener()
  				{
  					@Override
  					public void onClick(DialogInterface llllJIJ, int llllJI1)
  					{
  						Intent llllJlI = new Intent(llllIIJ, OpenVPNClient.class);
  						int llllJll = 123456;
  						PendingIntent llllJl = PendingIntent.getActivity(llllIIJ, llllJll,    llllJlI, PendingIntent.FLAG_CANCEL_CURRENT);
  						AlarmManager llllJlJ = (AlarmManager)llllIIJ.getSystemService(Context.ALARM_SERVICE);
  						llllJlJ.set(AlarmManager.RTC, System.currentTimeMillis() + 100, llllJl);
  						System.exit(0);
					}
				};
			}
		}

  		private class llllIll extends AsyncTask<String, String,JSONObject>
  		{
  			@Override
  			protected JSONObject doInBackground(String... llllJI1)
  			{
  				HttpURLConnection llllIJI = null;
  				try {
  					URL url = new URL(llllJI1[0]);
  					llllIJI = (HttpURLConnection)url.openConnection();
					llllIJI.connect();

  					StringBuilder b = new StringBuilder();
  					Reader llllJ1l = new BufferedReader(new InputStreamReader(url.openStream()));
  					char[] c = new char[1024];
  					while (true) {
  						int read = llllJ1l.read(c, 0, c.length);
  						if (read <= 0) {
  							break;
						}
  						b.append(c, 0, read);
					}
  					return new JSONObject(b.toString());
  				} catch (Exception e) {
  				} finally {
  					llllIJI.disconnect();
  				}
  				return null;
  			}
  			@Override
  			protected void onPostExecute(JSONObject result)
  			{
  				try {
  					JSONObject llllJ = result;
  					String versionfile = new JSONObject(llllJ1(new File(llllIIJ.getFilesDir(), "Version.txt"))).getString("Version");
  					String version = llllJ.getString("Version");
  					String url = llllJ.getString("Url");
					String changelog = llllJ.getString("Changelog");
  					if (llll1l(version, versionfile)) {
  						llllIJ(version, url, changelog);
  						File file = new File(llllIIJ.getFilesDir(), "Version.txt");
  						OutputStream out = new FileOutputStream(file);
  						out.write(result.toString().getBytes());
  						out.flush();
  						out.close();
					} else {
  						if (first) {
  							return;
						} else {
  							llllJ1I();
						}
					}
				} catch (Exception e) {
				}
  				super.onPostExecute(result);
  			}
  		}
  		private void llllI1J()
  		{
  			try {
  				File file = new File(llllIIJ.getFilesDir(), "Version.txt");
  				JSONObject o = new JSONObject();
				o.put("Version", "1.0");
  				OutputStream out = new FileOutputStream(file);
  			    out.write(o.toString().getBytes());
  				out.flush();
  				out.close();
  				llllI1.putBoolean("isFirstRun",true).apply();
			} catch (Exception e) {
			}
  		}
  		private boolean llll1l(String llllIl1, String llllII) {
  			String[] llllJ11 = llllIl1.split("\\.");
  			String[] llll1 = llllII.split("\\.");
  			int i = 0;
  			while (i < llllJ11.length && i < llll1.length && llllJ11[i].equals(llll1[i])) {
  				i++;
  			}
  			if (i < llllJ11.length && i < llll1.length) {
  				int llllIJ1 = Integer.valueOf(llllJ11[i]).compareTo(Integer.valueOf(llll1[i]));
  				return Integer.signum(llllIJ1) > 0;
  			}
  			return Integer.signum(llllJ11.length - llll1.length) > 0;
  		}
  		public String llllJ1(File file)
  		{
  			StringBuilder b = new StringBuilder();
  			try
  			{
  				InputStream in = new FileInputStream(file);
  				Reader llllJ1l = new BufferedReader(new InputStreamReader(in));
  				char[] c = new char[1024];
  				while (true) {
  					int read = llllJ1l.read(c, 0, c.length);
  					if (read <= 0) {
  						break;
  					}
  					b.append(c, 0, read);

				}

			}
  			catch (Exception e) {
  			}
  			return b.toString();
  		}
  		public void t(String s)

  		{
  			Toast.makeText(llllIIJ,s,-1).show();

		}

	}

	protected boolean isConnected()
	{
		boolean enabled = true;

		ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo info = connectivityManager.getActiveNetworkInfo();

		if ((info == null || !info.isConnected() || !info.isAvailable())) {
			enabled = false;
			Toast.makeText(this, "ไม่มีการเชื่อมต่ออินเทอร์เน็ต",-1).show();
		}
		return enabled;	
	}
	
	
	
	
	
	
    protected void onNewIntent(Intent intent) {
        String str = TAG;
        Object[] objArr = new Object[S_BIND_CALLED];
        objArr[0] = intent.toString();
        Log.d(str, String.format("CLI: onNewIntent intent=%s", objArr));
        setIntent(intent);
    }
 
    protected void post_bind() {
        Log.d(TAG, "CLI: post bind");
        this.startup_state |= S_BIND_CALLED;
        process_autostart_intent(is_active());
        render_last_event();
    }
 
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
 
    public void event(EventMsg ev) {
        render_event(ev, RETAIN_AUTH, is_active(), RETAIN_AUTH);
    }
 
    private void render_last_event() {
        boolean active = is_active();
        EventMsg ev = get_last_event();
        if (ev != null) {
            render_event(ev, true, active, true);
        } else if (n_profiles_loaded() > 0) {
            render_event(EventMsg.disconnected(), true, active, true);
        } else {
            hide_status();
            ui_setup(active, UIF_RESET, null);
            show_progress(0, active);
			
			
        }
        EventMsg pev = get_last_event_prof_manage();
        if (pev != null) {
            render_event(pev, true, active, true);
        }
    }
 
    private boolean show_conn_info_field(String text, int field_id, int row_id) {
        int i = 0;
        boolean vis = text.length() > 0 ? true : RETAIN_AUTH;
        TextView tv = (TextView) findViewById(field_id);
        View row = findViewById(row_id);
        tv.setText(text);
        if (!vis) {
            i = 8;
        }
        row.setVisibility(i);
        return vis;
    }
 
    private void reset_conn_info() {
        show_conn_info(new ClientAPI_ConnectionInfo());
    }
 
    private void show_conn_info(ClientAPI_ConnectionInfo ci) {
        this.info_group.setVisibility((((((((RETAIN_AUTH | show_conn_info_field(ci.getVpnIp4(), R.id.ipv4_addr, R.id.ipv4_addr_row)) | show_conn_info_field(ci.getVpnIp6(), R.id.ipv6_addr, R.id.ipv6_addr_row)) | show_conn_info_field(ci.getUser(), R.id.user, R.id.user_row)) | show_conn_info_field(ci.getClientIp(), R.id.client_ip, R.id.client_ip_row)) | show_conn_info_field(ci.getServerHost(), R.id.server_host, R.id.server_host_row)) | show_conn_info_field(ci.getServerIp(), R.id.server_ip, R.id.server_ip_row)) | show_conn_info_field(ci.getServerPort(), R.id.server_port, R.id.server_port_row)) | show_conn_info_field(ci.getServerProto(), R.id.server_proto, R.id.server_proto_row) ? 0 : 8);
        set_visibility_stats_expansion_group();
    }
 
    private void set_visibility_stats_expansion_group() {
        int i = 0;
        boolean expand_stats = this.prefs.get_boolean("expand_stats", RETAIN_AUTH);
        View view = this.stats_expansion_group;
        if (!expand_stats) {
            i = 8;
        }
        view.setVisibility(i);
        this.details_more_less.setText(expand_stats ? R.string.touch_less : R.string.touch_more);
    }
 
    private void render_event(EventMsg ev, boolean reset, boolean active, boolean cached) {
        int flags = ev.flags;
        if (ev.is_reflected(this)) {
            flags |= UIF_REFLECTED;
        }
        if (reset || (flags & 8) != 0 || ev.profile_override != null) {
            ui_setup(active, UIF_RESET | flags, ev.profile_override);
        } else if (ev.res_id == R.string.core_thread_active) {
            active = true;
            ui_setup(true, flags, null);
        } else if (ev.res_id == R.string.core_thread_inactive) {
            active = RETAIN_AUTH;
            ui_setup(RETAIN_AUTH, flags, null);
        }
        switch (ev.res_id) {
            case R.string.connected /*2131034168*/:
                this.main_scroll_view.fullScroll(33);
                break;
            case R.string.info_msg /*2131034237*/:
                if (ev.info.startsWith("OPEN_URL:")) {
                    Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(ev.info.substring(9)));
                    intent.putExtra("com.android.browser.application_id", getPackageName());
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivity(intent);
                        break;
                    }
                }
                break;
            case R.string.tap_not_supported /*2131034362*/:
                if (!cached) {
                    ok_dialog(resString(R.string.tap_unsupported_title), resString(R.string.tap_unsupported_error));
                    break;
                }
                break;
            case R.string.tun_iface_create /*2131034371*/:
                if (!cached) {
                    ok_dialog(resString(R.string.tun_ko_title), resString(R.string.tun_ko_error));
                    break;
                }
                break;
            case R.string.warn_msg /*2131034390*/:
                this.delayed_finish_on_connect = FinishOnConnect.PENDING;
                final Activity self = this;
                ok_dialog(resString(R.string.warning_title), ev.info, new Runnable() {
                    public void run() {
                        if (!(OpenVPNClient.this.delayed_finish_on_connect == FinishOnConnect.PENDING || OpenVPNClient.this.delayed_finish_on_connect == FinishOnConnect.DISABLED)) {
                            self.finish();
                        }
                        OpenVPNClient.this.delayed_finish_on_connect = FinishOnConnect.DISABLED;
                    }
                });
                break;
        }
        if (ev.priority >= S_BIND_CALLED) {
            if (ev.icon_res_id >= 0) {
                show_status_icon(ev.icon_res_id);
				
				
            }
			
			
			
            if (ev.res_id == R.string.connected) {
				
				
				NotificationBar.create(OpenVPNClient.this)

					.setIcon(R.drawable.check_successful)
					.setTitle(R.string.app)
					.setTitleColor(R.color.material_green)
					.setBackgroundColor(R.color.white)
					.setMessage("เชื่อมต่อสำเร็จ")
					.setNotificationPosition(NotificationBar.BOTTOM)
					.show();
					
				showInterstitial();
				
			//TastyToast.makeText(getApplicationContext(), "SoeVPN: Connected", TastyToast.LENGTH_SHORT, TastyToast.SUCCESS);
				/**Circle stop button**/				
				
//Ripple effect
				main_rippleBackground.stopRippleAnimation();
				main_rippleBackground2.startRippleAnimation();
				stop_connect.setVisibility(8);
				this.status_view.setTextColor(Color.parseColor("#4CAF50"));
				stop_connect.setOnClickListener(new OnClickListener(){

						@Override
						public void onClick(View p1) {

							connect();
						}

					});
				
                show_status(ev.res_id);
                if (ev.conn_info != null) {
                    show_conn_info(ev.conn_info);
                }
            } else if (ev.info.length() > 0) {
				
                Object[] objArr = new Object[S_ONSTART_CALLED];
                objArr[0] = resString(ev.res_id);
                objArr[S_BIND_CALLED] = ev.info;
                show_status(String.format("%s : %s", objArr));
            } else {
                show_status(ev.res_id);
				stop_connect.setVisibility(8);
				//Ripple effect

				this.status_view.setTextColor(Color.parseColor("#F44336"));
				main_rippleBackground2.stopRippleAnimation();
				main_rippleBackground.startRippleAnimation();
				
            }
			
        }
        show_progress(ev.progress, active);
        show_stats();
        if (ev.res_id == R.string.connected && this.finish_on_connect != FinishOnConnect.DISABLED) {
            if (this.prefs.get_boolean("autostart_finish_on_connect", RETAIN_AUTH)) {
                final OpenVPNClient self = this;
                if (this.delayed_finish_on_connect == FinishOnConnect.PENDING)
				{
                    this.delayed_finish_on_connect = this.finish_on_connect;
                    return;
                }
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        if (OpenVPNClient.this.finish_on_connect != FinishOnConnect.DISABLED) {
                            self.finish();
                        }
                    }
                }, 1000);
                return;
            }
            this.finish_on_connect = FinishOnConnect.DISABLED;
        }
    }

	private void ok_dialog(String resString, String info, Object run)
	{
		// TODO: Implement this method
	}
 
    private void stop_service() {
        submitDisconnectIntent(true);

		
		
		
    }
 
    private void stop() {
        cancel_stats();
		
        doUnbindService();
        if (this.stop_service_on_client_exit) {
            Log.d(TAG, "CLI: stopping service");
            stop_service();
			
			
        }
    }
 
    protected void onStop() {
        Log.d(TAG, "CLI: onStop");
        cancel_stats();
        super.onStop();
		
    }
 
    protected void onStart() {
        super.onStart();
        Log.d(TAG, "CLI: onStart");
        this.startup_state |= S_ONSTART_CALLED;
        if (this.finish_on_connect == FinishOnConnect.ENABLED) {
			
            this.finish_on_connect = FinishOnConnect.ENABLED_ACROSS_ONSTART;
        }
        boolean active = is_active();
        if (active) {
            schedule_stats();
        }
        if (process_autostart_intent(active)) {
            ui_setup(active, UIF_RESET, null);
        }
    }
 
    protected void onDestroy() {
        stop();
		if (mAdView != null) {
            mAdView.destroy();
        }
        Log.d(TAG, "CLI: onDestroy called");
        super.onDestroy();
    }
 
    private boolean process_autostart_intent(boolean active) {
        if ((this.startup_state & REQUEST_IMPORT_PKCS12) == REQUEST_IMPORT_PKCS12) {
            Intent intent = getIntent();
            String apn_key = "shwelu.shanlayvpn.net.AUTOSTART_PROFILE_NAME";
            String apn = intent.getStringExtra(apn_key);
            if (apn != null) {
                this.autostart_profile_name = null;
                String str = TAG;
                Object[] objArr = new Object[S_BIND_CALLED];
                objArr[0] = apn;
                Log.d(str, String.format("CLI: autostart: %s", objArr));
                intent.removeExtra(apn_key);
                if (!active) {
                    ProfileList proflist = profile_list();
                    if (proflist == null || proflist.get_profile_by_name(apn) == null) {
                        ok_dialog(resString(R.string.profile_not_found), apn);
                    } else {
                        this.autostart_profile_name = apn;
                        return true;
                    }
                } else if (!current_profile().get_name().equals(apn)) {
                    this.autostart_profile_name = apn;
                    submitDisconnectIntent(RETAIN_AUTH);
                }
            }
        }
        return RETAIN_AUTH;
    }
 
    private void cancel_ui_reset() {
        this.ui_reset_timer_handler.removeCallbacks(this.ui_reset_timer_task);
    }
 
    private void schedule_ui_reset(long delay) {
        cancel_ui_reset();
        this.ui_reset_timer_handler.postDelayed(this.ui_reset_timer_task, delay);
    }
 
    private void hide_status() {
		
        this.status_view.setVisibility(8);
    }
 
    private void show_status(String text) {
        this.status_view.setVisibility(0);
        this.status_view.setText(text);
    }
 
    private void show_status(int res_id) {
        this.status_view.setVisibility(0);
        this.status_view.setText(res_id);
    }
	
	
 
    private void show_status_icon(int res_id) {
        this.status_icon_view.setImageResource(res_id);
		
    }
 
    private void show_progress(int progress, boolean active) {
        if (progress <= 0 || progress >= 99) {
            this.progress_bar.setVisibility(8);
			
            return;
        }
        this.progress_bar.setVisibility(0);
        this.progress_bar.setProgress(progress);

    }
 
    private void cancel_stats() {
        this.stats_timer_handler.removeCallbacks(this.stats_timer_task);
    }
 
    private void schedule_stats() {
        cancel_stats();
        this.stats_timer_handler.postDelayed(this.stats_timer_task, 1000);
    }
 
    private static String render_bandwidth(long bw) {
        String postfix;
        float div;
        Object[] objArr;
        float bwf = (float) bw;
        if (bwf >= 1.0E12f) {
            postfix = "TB";
            div = 1.0995116E12f;
        } else if (bwf >= 1.0E9f) {
            postfix = "GB";
            div = 1.0737418E9f;
        } else if (bwf >= 1000000.0f) {
            postfix = "MB";
            div = 1048576.0f;
        } else if (bwf >= 1000.0f) {
            postfix = "KB";
            div = 1024.0f;
        } else {
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Float.valueOf(bwf);
            return String.format("%.0f", objArr);
        }
        objArr = new Object[S_ONSTART_CALLED];
        objArr[0] = Float.valueOf(bwf / div);
        objArr[S_BIND_CALLED] = postfix;
        return String.format("%.2f %s", objArr);
    }
 
    private String render_last_pkt_recv(int sec) {
        if (sec >= 3600) {
            return resString(R.string.lpr_gt_1_hour_ago);
        }
        String resString;
        Object[] objArr;
        if (sec >= 120) {
            resString = resString(R.string.lpr_gt_n_min_ago);
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Integer.valueOf(sec / 60);
            return String.format(resString, objArr);
        } else if (sec >= S_ONSTART_CALLED) {
            resString = resString(R.string.lpr_n_sec_ago);
            objArr = new Object[S_BIND_CALLED];
            objArr[0] = Integer.valueOf(sec);
            return String.format(resString, objArr);
        } else if (sec == S_BIND_CALLED) {
            return resString(R.string.lpr_1_sec_ago);
        } else {
            if (sec == 0) {
                return resString(R.string.lpr_lt_1_sec_ago);
            }
            return "";
        }
    }
 
    private void show_stats() {
        if (is_active()) {
            ConnectionStats stats = get_connection_stats();
            this.last_pkt_recv_view.setText(render_last_pkt_recv(stats.last_packet_received));
            this.duration_view.setText(OpenVPNClientBase.render_duration(stats.duration));
            this.bytes_in_view.setText(render_bandwidth(stats.bytes_in));
            this.bytes_out_view.setText(render_bandwidth(stats.bytes_out));
        }
    }
 
    private void clear_stats() {
        this.last_pkt_recv_view.setText("");
        this.duration_view.setText("");
        this.bytes_in_view.setText("");
        this.bytes_out_view.setText("");
        reset_conn_info();
    }
 
    private int n_profiles_loaded() {
        ProfileList proflist = profile_list();
        if (proflist != null) {
            return proflist.size();
        }
        return 0;
    }
 
    private String selected_profile_name() {
        String ret = null;
        ProfileList proflist = profile_list();
        if (proflist != null && proflist.size() > 0) {
            ret = proflist.size() == S_BIND_CALLED ? ((Profile) proflist.get(0)).get_name() : SpinUtil.get_spinner_selected_item(this.profile_spin);
        }
        if (ret == null) {
            return "UNDEFINED_PROFILE";
        }
        return ret;
    }
 
    private Profile selected_profile() {
        ProfileList proflist = profile_list();
        if (proflist != null) {
            return proflist.get_profile_by_name(selected_profile_name());
        }
        return null;
    }
 
    private void clear_auth() {
        this.username_edit.setText("");
        this.pk_password_edit.setText("");
        this.password_edit.setText("");
        this.response_edit.setText("");
    }
 
    private void ui_setup(boolean active, int flags, String profile_override) {
        boolean orig_active = active;
        boolean autostart = RETAIN_AUTH;
        cancel_ui_reset();
        if (!((UIF_RESET & flags) == 0 && orig_active == this.last_active)) {
            clear_auth();
			
            if (!(active || this.autostart_profile_name == null)) {
                autostart = true;
                profile_override = this.autostart_profile_name;
                this.autostart_profile_name = null;
            }
            ProfileList proflist = profile_list();
            Profile prof = null;
            if (proflist == null || proflist.size() <= 0) {
                this.profile_group.setVisibility(8);
				this.load_server_layout.setVisibility(0);
            } else {
                ProfileSource ps = ProfileSource.UNDEF;
                SpinUtil.show_spinner(this, this.profile_spin, proflist.profile_names());
                if (active) {
                    ps = ProfileSource.SERVICE;
                    prof = current_profile();
                }
                if (prof == null && profile_override != null) {
                    ps = ProfileSource.PRIORITY;
                    prof = proflist.get_profile_by_name(profile_override);
                    if (prof == null) {
                        Log.d(TAG, "CLI: profile override not found");
                        autostart = RETAIN_AUTH;
                    }
                }
                if (prof == null) {
                    if ((UIF_PROFILE_SETTING_FROM_SPINNER & flags) != 0) {
                        ps = ProfileSource.SPINNER;
                        prof = proflist.get_profile_by_name(SpinUtil.get_spinner_selected_item(this.profile_spin));
                    } else {
                        ps = ProfileSource.PREFERENCES;
                        prof = proflist.get_profile_by_name(this.prefs.get_string("profile"));
                    }
                }
                if (prof == null) {
                    ps = ProfileSource.LIST0;
                    prof = (Profile) proflist.get(0);
                }
                if (ps != ProfileSource.PREFERENCES && (UIF_REFLECTED & flags) == 0) {
                    this.prefs.set_string("profile", prof.get_name());
                    gen_ui_reset_event(true);
                }
                if (ps != ProfileSource.SPINNER) {
                    SpinUtil.set_spinner_selected_item(this.profile_spin, prof.get_name());
                }
                this.profile_group.setVisibility(0);
				this.load_server_layout.setVisibility(8);
				this.select_server.setEnabled(!active ? true : RETAIN_AUTH);
                this.profile_spin.setEnabled(!active ? true : RETAIN_AUTH);
                this.profile_edit.setVisibility(active ? 8 : 0);
            }
            if (prof != null) {
                if ((UIF_RESET & flags) != 0) {
                    prof.reset_dynamic_challenge();
                }
                EditText focus = null;
                if (!active && (flags & 32) != 0) {
                    this.post_import_help_blurb.setVisibility(0);
                } else if (active) {
                    this.post_import_help_blurb.setVisibility(8);
                }
                ProxyList proxy_list = get_proxy_list();
                if (active || proxy_list.size() <= 0) {
                    this.proxy_group.setVisibility(8);
                } else {
                    SpinUtil.show_spinner(this, this.proxy_spin, proxy_list.get_name_list(true));
                    String name = proxy_list.get_enabled(true);
                    if (name != null) {
                        SpinUtil.set_spinner_selected_item(this.proxy_spin, name);
                    }
                    this.proxy_group.setVisibility(0);
                }
                if (active || !prof.server_list_defined()) {
                    this.server_group.setVisibility(8);
                } else {
                    SpinUtil.show_spinner(this, this.server_spin, prof.get_server_list().display_names());
                    String server = this.prefs.get_string_by_profile(prof.get_name(), "server");
                    if (server != null) {
                        SpinUtil.set_spinner_selected_item(this.server_spin, server);
                    }
                    this.server_group.setVisibility(0);
                }
                if (active) {
                    this.username_group.setVisibility(8);
                    this.pk_password_group.setVisibility(8);
                    this.password_group.setVisibility(8);
                } else {
                    boolean is_pwd_save;
                    String saved_pwd;
                    boolean udef = prof.userlocked_username_defined();
                    boolean autologin = prof.get_autologin();
                    boolean pk_pwd_req = prof.get_private_key_password_required();
                    boolean dynamic_challenge = prof.is_dynamic_challenge();
                    if ((!autologin || (autologin && udef)) && !dynamic_challenge) {
                        if (udef) {
                            this.username_edit.setText(prof.get_userlocked_username());
                            set_enabled(this.username_edit, RETAIN_AUTH);
							
                        } else {
                            set_enabled(this.username_edit, true);
							
                            String pref_username = this.prefs.get_string_by_profile(prof.get_name(), "username");
                            if (pref_username != null) {
                                this.username_edit.setText(pref_username);
                            } else if (null == null) {
                                focus = this.username_edit;
                            }
                        }
                        this.username_group.setVisibility(0);
                    } else {
                        this.username_group.setVisibility(8);
                    }
                    if (pk_pwd_req) {
                        is_pwd_save = this.prefs.get_boolean_by_profile(prof.get_name(), "pk_password_save", RETAIN_AUTH);
                        saved_pwd = null;
                        this.pk_password_group.setVisibility(0);
                        this.pk_password_save_checkbox.setChecked(is_pwd_save);
                        if (is_pwd_save) {
                            saved_pwd = this.pwds.get("pk", prof.get_name());
                        }
                        if (saved_pwd != null) {
                            this.pk_password_edit.setText(saved_pwd);
                        } else if (focus == null) {
                            focus = this.pk_password_edit;
                        }
                    } else {
                        this.pk_password_group.setVisibility(8);
                    }
					
					
                    if (autologin || dynamic_challenge) {
                        this.password_group.setVisibility(8);
						this.username_group.setVisibility(8);
		//limit time
		
						this.vip_icon.setVisibility(8);
						
						btnAddTime.setVisibility(0);
						timeAPI.start(tvRemainingTime, this);
						addtime_info.setText("If timeout the connection will be disconnected");
						addtime_info.setTextColor(Color.parseColor("#FF992A"));
		
						
                    } else {
						
		// Unlimited time
		
				
						timeAPI.stop();
						addtime_info.setText("This feature is available to VIP user only");
						addtime_info.setTextColor(Color.parseColor("#4CAF50"));
						btnAddTime.setVisibility(8);
						this.vip_icon.setVisibility(0);
						
                        boolean is_auth_pw_save = prof.get_allow_password_save();
                        is_pwd_save = (is_auth_pw_save && this.prefs.get_boolean_by_profile(prof.get_name(), "auth_password_save", RETAIN_AUTH)) ? true : RETAIN_AUTH;
                        saved_pwd = null;
                        this.password_group.setVisibility(0);
						this.username_group.setVisibility(0);
                        this.password_save_checkbox.setEnabled(is_auth_pw_save);
                        this.password_save_checkbox.setChecked(is_pwd_save);
                        if (is_pwd_save) {
                            saved_pwd = this.pwds.get("auth", prof.get_name());
                        }else{
							
							
						}
                        if (saved_pwd != null) {
                            this.password_edit.setText(saved_pwd);
                        } else if (focus == null) {
                            focus = this.password_edit;
							
                        }
                    }
                }
                if (active || prof.get_autologin() || !prof.challenge_defined()) {
                    this.cr_group.setVisibility(8);
                } else {
                    this.cr_group.setVisibility(0);
                    Challenge chal = prof.get_challenge();
                    this.challenge_view.setText(chal.get_challenge());
                    this.challenge_view.setVisibility(0);
                    if (chal.get_response_required()) {
                        if (chal.get_echo()) {
                            this.response_edit.setTransformationMethod(SingleLineTransformationMethod.getInstance());
                        } else {
                            this.response_edit.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        }
                        this.response_edit.setVisibility(0);
                        if (focus == null) {
                            focus = this.response_edit;
                        }
                    } else {
                        this.response_edit.setVisibility(8);
                    }
                    if (prof.is_dynamic_challenge()) {
                        schedule_ui_reset(prof.get_dynamic_challenge_expire_delay());
                    }
                }
                this.button_group.setVisibility(0);
                if (orig_active) {
                    this.conn_details_group.setVisibility(0);
                    this.connect_button.setVisibility(8);
					
                    this.disconnect_button.setVisibility(0);
					
					
					/**** TIME API START POINT  ****/
			//		timeAPI.start(tvRemainingTime, this);
					/******************************/
					
				    boolean autologin = prof.get_autologin();
					boolean dynamic_challenge = prof.is_dynamic_challenge();
					if (autologin || dynamic_challenge) {
                        

						//limit time

						this.vip_icon.setVisibility(8);
						btnAddTime.setVisibility(0);
						timeAPI.start(tvRemainingTime, this);
						addtime_info.setText("If timeout the connection will be disconnected");
						addtime_info.setTextColor(Color.parseColor("#FF992A"));


                    } else {

						// Unlimited time

						timeAPI.stop();
						addtime_info.setText("This feature is available to VIP user only");
						addtime_info.setTextColor(Color.parseColor("#4CAF50"));
						btnAddTime.setVisibility(8);
						this.vip_icon.setVisibility(0);
						}
					
					
                } else {
                    this.conn_details_group.setVisibility(8);
                    this.connect_button.setVisibility(0);
			
                    this.disconnect_button.setVisibility(8);
					
					
					/**** TIME API STOP POINT  ****/
				//	timeAPI.stop();
					/******************************/
					
                }
                if (focus != null) {
                    autostart = RETAIN_AUTH;
                }
                req_focus(focus);
            } else {
                this.post_import_help_blurb.setVisibility(8);
                this.proxy_group.setVisibility(8);
                this.server_group.setVisibility(8);
                this.username_group.setVisibility(8);
                this.pk_password_group.setVisibility(8);
                this.password_group.setVisibility(8);
                this.cr_group.setVisibility(8);
                this.conn_details_group.setVisibility(8);
                this.button_group.setVisibility(8);
                show_status_icon(R.drawable.info);
                show_status(R.string.no_profiles_loaded);
            }
            if (orig_active) {
                schedule_stats();
            } else {
                cancel_stats();
            }
        }
        this.last_active = orig_active;
        if (autostart && !this.last_active) {
            this.finish_on_connect = FinishOnConnect.ENABLED;
            start_connect();
        }
    }
 
    private void set_enabled(EditText editText, boolean state) {
        editText.setEnabled(state);
        editText.setFocusable(state);
        editText.setFocusableInTouchMode(state);
    }
 
    private void raise_file_selection_dialog(int requestCode) {
        switch (requestCode) {
            case S_ONSTART_CALLED /*2*/:
                raise_file_selection_dialog(S_ONSTART_CALLED, R.string.select_profile);
                return;
            case REQUEST_IMPORT_PKCS12 /*3*/:
                raise_file_selection_dialog(REQUEST_IMPORT_PKCS12, R.string.select_pkcs12);
                return;
            default:
                return;
        }
    }
 
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (grantResults.length != 0) {
            switch (requestCode) {
                case S_ONSTART_CALLED /*2*/:
                case REQUEST_IMPORT_PKCS12 /*3*/:
                    int i = 0;
                    while (i < grantResults.length) {
                        if (permissions[i].equals("android.permission.READ_EXTERNAL_STORAGE") && grantResults[i] == 0) {
                            raise_file_selection_dialog(requestCode);
                        }
                        i += S_BIND_CALLED;
                    }
                    return;
                default:
                    return;
            }
        }
    }
	
	public void show_case(){
		RelativeLayout select_profile = (RelativeLayout)findViewById(R.id.select_profile);
		new GuideView.Builder(this)
			.setTitle("เซิร์ฟเวอร์ & SIM Pro")
			.setContentText("เลือกเซิร์ฟเวอร์ที่ต้องการ")
			.setGravity(Gravity.auto)
			.setTargetView(select_profile)
			.setDismissType(DismissType.anywhere) //optional - default dismissible by TargetView
			.setGuideListener(new GuideListener() {
				@Override
				public void onDismiss(View view) {
					//TODO ...
					show_connect();
				}
			})
			.build()
			.show();		
		
	}
	
	public void show_connect(){
		new GuideView.Builder(this)
			.setTitle("เชื่อมต่อและยกเลิกการเชื่อมต่อ")
			.setContentText("คลิกที่นี่เพื่อเชื่อมต่อกับ VPN")
			.setGravity(Gravity.auto)
			.setTargetView(connect_button)
			.setDismissType(DismissType.anywhere) //optional - default dismissible by TargetView
			.setGuideListener(new GuideListener() {
				@Override
				public void onDismiss(View view) {
					//TODO ...
					show_Time();
				}
			})
			.build()
			.show();
	}
	
	public void show_Time(){
		RelativeLayout show_time = (RelativeLayout)findViewById(R.id.show_time);
		new GuideView.Builder(this)
			.setTitle("ตัวนับเวลาที่เหลือ")
			.setContentText("ถ้าคุณต้องการเวลามากขึ้น \nคลิกปุ่มเพิ่มเวลา")
			.setGravity(Gravity.center)
			.setTargetView(show_time)
			.setDismissType(DismissType.anywhere) //optional - default dismissible by TargetView
			.setGuideListener(new GuideListener() {
				@Override
				public void onDismiss(View view) {
					//TODO ...
				
				}
			})
			.build()
			.show();
	}
	
	
 
    private void request_file_selection_dialog(int requestCode) {
        if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == 0) {
            raise_file_selection_dialog(requestCode);
            return;
        }
        String[] perms = new String[S_BIND_CALLED];
        perms[0] = "android.permission.READ_EXTERNAL_STORAGE";
        ActivityCompat.requestPermissions(this, perms, requestCode);
    }
 
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
			
		case R.id.day_night:
				showInterstitial();
				final Dialog dialog = new Dialog(OpenVPNClient.this);
				dialog.setContentView(R.layout.change_theme);
				dialog.setCancelable(false);
				dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);

				dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
				dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;
				
				Button light_mode = dialog.findViewById(R.id.light_mode);
				light_mode.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v){

							dialog.cancel();
							setCurrentThemeId(16974410,R.drawable.dark_mode_ic,0);


						}
					});
				
				Button normal_mode = dialog.findViewById(R.id.day_mode);
				normal_mode.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v){

							dialog.cancel();
							setCurrentThemeId(16974407,R.drawable.dark_mode_ic,0);


						}
					});
				
				Button start = dialog.findViewById(R.id.night_mode);
				start.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v){

							dialog.cancel();
							setCurrentThemeId(16974411,R.drawable.light_mode_ic,8);


						}
					});


				
				dialog.show();



				Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);
				TextView title = dialog.findViewById(R.id.title);
				TextView message = dialog.findViewById(R.id.message);
				ImageView img = dialog.findViewById(R.id.img);

				message.setText("การเชื่อมต่อจะถูกตัดการเชื่อมต่อ");
				title.setText("ตัวเปลี่ยนธีม");
				
				img.setAnimation(slideUp);
				img.startAnimation(slideUp);


				ImageView close = dialog.findViewById(R.id.close);

				close.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v){

							dialog.cancel();

						}
					});
				return true;
				
				case R.id.show_case:
					
					show_case();
					
					return true;
			
		//	case R.id.dynamic_settings:
		//		api_vip();
		//		return true;
				
			case R.id.rate_vpn:
				String rate = "https://play.google.com/store/apps/details?id=eagle.pro.net";
				fb(rate);
				return true;
			case R.id.speed_test_action:
				final Dialog dialog4 = new Dialog(OpenVPNClient.this);
				dialog4.setContentView(R.layout.speed_test);
				dialog4.setCancelable(false);
				dialog4.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,WindowManager.LayoutParams.WRAP_CONTENT);
				dialog4.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
				dialog4.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

				Button close4 = (Button)dialog4.findViewById(R.id.close);
				close4.setOnClickListener(new OnClickListener(){

						@Override
						public void onClick(View p1) {
							dialog4.cancel();
						}
					});

				LinearLayout speed_bt = (LinearLayout)dialog4.findViewById(R.id.speed_bt);
				speed_bt.setOnClickListener(new OnClickListener(){

						@Override
						public void onClick(View p1) {
							loadUrl(speed);
							dialog4.cancel();
						}
					});

				LinearLayout fast_bt = (LinearLayout)dialog4.findViewById(R.id.fast_bt);
				fast_bt.setOnClickListener(new OnClickListener(){

						@Override
						public void onClick(View p1) {
							loadUrl(fast);
							dialog4.cancel();
						}
					});


				dialog4.show();
				
				return true;
			case R.id.settings_action:
				request_file_selection_dialog(S_ONSTART_CALLED);
				return true;
			case R.id.open_apn:
				openAPNSettings();
			
				return true;
				
			case R.id.check_update:
				check_update();
				return true;
			
			case R.id.about_layout:
				info();
		
				return true;
			case R.id.share_vpn:
				Intent myIntent = new Intent(Intent.ACTION_SEND);
				myIntent.setType("text/plain");
				String body = getString(R.string.share_link);
				String sub = "😱😱ฉันพบแอปอินเทอร์เน็ตฟรี มันเจ๋งมาก คุณสามารถใช้ได้ด้วย";
				myIntent.putExtra(Intent.EXTRA_SUBJECT,sub);
				myIntent.putExtra(Intent.EXTRA_TEXT,body);
				startActivity(Intent.createChooser(myIntent, "Share Using"));
				return true;		
			
			
            case R.id.about_menu /*2131427498*/:
                startActivityForResult(new Intent(this, OpenVPNAbout.class), 0);
                return true;
			case R.id.reset_app:
				
				
				final Dialog dialog_delet = new Dialog(OpenVPNClient.this);
				dialog_delet.setContentView(R.layout.clear_data);
				dialog_delet.setCancelable(false);
				dialog_delet.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);

				dialog_delet.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
				dialog_delet.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;


				Button start4 = dialog_delet.findViewById(R.id.start);
				start4.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v){
							showInterstitial();
							deleteAppData();
							
						}
					});
				dialog_delet.show();



				Animation slideUp4 = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);
				TextView title4 = dialog_delet.findViewById(R.id.title);
				TextView message4 = dialog_delet.findViewById(R.id.message);
				ImageView img4 = dialog_delet.findViewById(R.id.img);

				message4.setText("คุณแน่ใจหรือไม่ว่าต้องการรีเซ็ต \\ข้อมูลทั้งหมดของคุณจะหายไป");
				title4.setText("รีเซ็ต TIK VPN");
				img4.setImageResource(R.drawable.icon);
				img4.setAnimation(slideUp4);
				img4.startAnimation(slideUp4);


				ImageView close3 = dialog_delet.findViewById(R.id.close);

				close3.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View v){

							dialog_delet.cancel();

						}
					});
							
				return true;
            case R.id.help_menu /*2131427499*/:
                startActivityForResult(new Intent(this, OpenVPNHelp.class), 0);
                return true;
            case R.id.import_private_tunnel_profile /*2131427501*/:
                startActivity(new Intent("android.intent.action.VIEW", Uri.parse(getText(R.string.privatetunnel_import).toString())));
                break;
            case R.id.import_profile_remote /*2131427502*/:
                startActivityForResult(new Intent(this, OpenVPNImportProfile.class), 0);
                return true;
            case R.id.import_profile /*2131427503*/:
                request_file_selection_dialog(S_ONSTART_CALLED);
                return true;
            case R.id.import_pkcs12 /*2131427504*/:
                request_file_selection_dialog(REQUEST_IMPORT_PKCS12);
                return true;
            case R.id.preferences /*2131427505*/:
                startActivityForResult(new Intent(this, OpenVPNPrefs.class), 0);
                return true;
			case R.id.settings:
				showInterstitial();
                startActivityForResult(new Intent(this, settings.class), 0);
			//	overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_left);
                return true;
				
            case R.id.add_proxy /*2131427506*/:
                String prefix = OpenVPNService.INTENT_PREFIX;
                startActivityForResult(new Intent(this, OpenVPNAddProxy.class), 0);
                return true;
            case R.id.add_shortcut_connect /*2131427508*/:
                startActivityForResult(new Intent(this, OpenVPNAddShortcut.class), 0);
                return true;
            case R.id.add_shortcut_disconnect /*2131427509*/:
                createDisconnectShortcut(resString(R.string.disconnect_shortcut_title));
                return true;
            case R.id.add_shortcut_app /*2131427510*/:
                createAppShortcut(resString(R.string.app_shortcut_title));
                return true;
            case R.id.show_log /*2131427511*/:
                startActivityForResult(new Intent(this, OpenVPNLog.class), 0);
                return true;
            case R.id.show_raw_stats /*2131427513*/:
                startActivityForResult(new Intent(this, OpenVPNStats.class), 0);
                return true;
            case R.id.forget_creds /*2131427514*/:
                forget_creds_with_confirm();
                return true;
            case R.id.exit_partial /*2131427515*/:
                finish();
                return true;
            case R.id.exit_full /*2131427516*/:
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        this.stop_service_on_client_exit = true;
        finish();
        return true;
    }

	private void createAppShortcut(String resString)
	{
		// TODO: Implement this method
	}

	private void createDisconnectShortcut(String resString)
	{
		// TODO: Implement this method
	}
 
    public void onClick(View v) {
        cancel_ui_reset();
        this.autostart_profile_name = null;
        this.finish_on_connect = FinishOnConnect.DISABLED;
        int viewid = v.getId();
        if (viewid == R.id.connect) {
            start_connect();
        } else if (viewid == R.id.disconnect) {
            submitDisconnectIntent(RETAIN_AUTH);
        } else if (viewid == R.id.profile_edit || viewid == R.id.proxy_edit || viewid == R.id.select_server) {
            // profile ‌ေရွးရန်
	
			
        }
    }
 
    private void start_connect() {
		/***** TIME API CHECK *****/
		
		if (timeAPI.hasValidTime()) {
			cancel_ui_reset();
			Intent intent = VpnService.prepare(this);
			if (intent != null) {
				try {
					Log.d(TAG, "CLI: requesting VPN actor rights");
					startActivityForResult(intent, S_BIND_CALLED);
					return;
				} catch (ActivityNotFoundException e) {
					Log.e(TAG, "CLI: requesting VPN actor rights failed", e);
					ok_dialog(resString(R.string.vpn_permission_dialog_missing_title), resString(R.string.vpn_permission_dialog_missing_text));
					return;
				}
			}
			resolve_epki_alias_then_connect();
			
		} else {
			
			show_toast("ไม่มีเวลาเหลือ",R.drawable.left_time_ic);
			final Dialog dialog = new Dialog(OpenVPNClient.this);
			dialog.setContentView(R.layout.alert_dialog);
			dialog.setCancelable(false);
			dialog.getWindow().setLayout(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT);
			dialog.getWindow().setBackgroundDrawable(getDrawable(R.drawable.custom_dialog_backgroung));
			dialog.getWindow().getAttributes().windowAnimations = R.style.PauseDialogAnimation;

Animation slideUp = AnimationUtils.loadAnimation(OpenVPNClient.this, R.anim.zoom_in);
			TextView title  = (TextView)dialog.findViewById(R.id.title);
			TextView message = (TextView)dialog.findViewById(R.id.message);
			ImageView img = (ImageView)dialog.findViewById(R.id.img);
			ImageView bt_tryagain = dialog.findViewById(R.id.bt_tryagain);
			Button add_time = (Button)dialog.findViewById(R.id.add_time);
			img.setAnimation(slideUp);
			img.startAnimation(slideUp);
			
			title.setText("ไม่มีเวลาเหลือ");
			message.setText("เพิ่มเวลาก่อนเชื่อมต่อ");
			img.setImageResource(R.drawable.noti_limit_ic);
			
			add_time.setOnClickListener(new OnClickListener(){

					@Override
					public void onClick(View p1) {
						add_time_dialog();
						dialog.cancel();
					}
				});

			bt_tryagain.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v){

						dialog.cancel();

					}
				});
			dialog.show();
		}
		
    }
 
    public boolean onTouch(View v, MotionEvent event) {
        boolean new_expand_stats = RETAIN_AUTH;
        if (v.getId() != R.id.conn_details_boxed || event.getAction() != 0) {
            return RETAIN_AUTH;
        }
        if (!this.prefs.get_boolean("expand_stats", RETAIN_AUTH)) {
            new_expand_stats = true;
        }
        this.prefs.set_boolean("expand_stats", new_expand_stats);
        set_visibility_stats_expansion_group();
        return true;
    }
 
    public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
        cancel_ui_reset();
        int viewid = parent.getId();
        if (viewid == R.id.profile) {
            ui_setup(is_active(), 327680, null);
        } else if (viewid == R.id.proxy) {
            ProxyList proxy_list = get_proxy_list();
            if (proxy_list != null) {
                proxy_list.set_enabled(SpinUtil.get_spinner_list_item(this.proxy_spin, position));
                proxy_list.save();
                gen_ui_reset_event(true);
            }
        } else if (viewid == R.id.server) {
            String server = SpinUtil.get_spinner_list_item(this.server_spin, position);
            this.prefs.set_string_by_profile(SpinUtil.get_spinner_selected_item(this.profile_spin), "server", server);
            gen_ui_reset_event(true);
        }
    }
 
    public void onNothingSelected(AdapterView<?> adapterView) {
    }
 
    private void menu_add(ContextMenu menu, int id, boolean enabled, String menu_key) {
        MenuItem item = menu.add(0, id, 0, id).setEnabled(enabled);
        if (menu_key != null) {
            item.setIntent(new Intent().putExtra("shwelu.shanlayvpn.net.MENU_KEY", menu_key));
        }
    }
 
    private String get_menu_key(MenuItem item) {
        if (item != null) {
            Intent intent = item.getIntent();
            if (intent != null) {
                return intent.getStringExtra("shwelu.shanlayvpn.net.MENU_KEY");
            }
        }
        return null;
    }
 
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        boolean z = RETAIN_AUTH;
        Log.d(TAG, "CLI: onCreateContextMenu");
        super.onCreateContextMenu(menu, v, menuInfo);
        int viewid = v.getId();
        if (!is_active() && (viewid == R.id.profile || viewid == R.id.profile_edit || viewid==R.id.select_server)) {
            Profile prof = selected_profile();
            if (prof != null) {
                String profile_name = prof.get_name();
                menu.setHeaderTitle(profile_name);
                if (SpinUtil.get_spinner_count(this.profile_spin) > S_BIND_CALLED) {
                    z = true;
                }
                menu_add(menu, R.string.profile_context_menu_change_profile, z, null);
                
                menu_add(menu, R.string.profile_context_menu_delete, prof.is_deleteable(), profile_name);
                menu_add(menu, R.string.profile_context_menu_rename, prof.is_renameable(), profile_name);
               
            } else {
                menu.setHeaderTitle(R.string.profile_context_none_selected);
            }
            menu_add(menu, R.string.profile_context_cancel, true, null);
        } else if (!is_active()) {
            if (viewid == R.id.proxy || viewid == R.id.proxy_edit) {
                ProxyList proxy_list = get_proxy_list();
                if (proxy_list != null) {
                    String proxy_name = proxy_list.get_enabled(true);
                    boolean is_none = proxy_list.is_none(proxy_name);
                    menu.setHeaderTitle(proxy_name);
                    menu_add(menu, R.string.proxy_context_change_proxy, SpinUtil.get_spinner_count(this.proxy_spin) > S_BIND_CALLED ? true : RETAIN_AUTH, null);
                    menu_add(menu, R.string.proxy_context_edit, !is_none ? true : RETAIN_AUTH, proxy_name);
                    if (!is_none) {
                        z = true;
                    }
                    menu_add(menu, R.string.proxy_context_delete, z, proxy_name);
                    menu_add(menu, R.string.proxy_context_forget_creds, proxy_list.has_saved_creds(proxy_name), proxy_name);
                } else {
                    menu.setHeaderTitle(R.string.proxy_context_none_selected);
                }
                menu_add(menu, R.string.proxy_context_cancel, true, null);
            }
        }
    }
 
    public boolean onContextItemSelected(MenuItem item) {
        Log.d(TAG, "CLI: onContextItemSelected");
        String prof_name;
        String proxy_name;
        switch (item.getItemId()) {
            case R.string.profile_context_cancel /*2131034278*/:
            case R.string.proxy_context_cancel /*2131034308*/:
                return true;
            case R.string.profile_context_forget_creds /*2131034279*/:
                ProfileList proflist = profile_list();
                if (proflist == null) {
                    return true;
                }
                Profile prof = proflist.get_profile_by_name(get_menu_key(item));
                if (prof == null) {
                    return true;
                }
                prof_name = prof.get_name();
                this.pwds.remove("pk", prof_name);
                this.pwds.remove("auth", prof_name);
                prof.forget_cert();
                ui_setup(is_active(), UIF_RESET, null);
                return true;
            case R.string.profile_context_menu_change_profile /*2131034280*/:
                this.profile_spin.performClick();
                return true;
            case R.string.profile_context_menu_create_shortcut /*2131034281*/:
                prof_name = get_menu_key(item);
                if (prof_name == null) {
                    return true;
                }
                launch_create_profile_shortcut_dialog(prof_name);
                return true;
            case R.string.profile_context_menu_delete /*2131034282*/:
                prof_name = get_menu_key(item);
                if (prof_name == null) {
                    return true;
                }
                submitDeleteProfileIntentWithConfirm(prof_name);
                return true;
            case R.string.profile_context_menu_rename /*2131034283*/:
                prof_name = get_menu_key(item);
                if (prof_name == null) {
                    return true;
                }
                launch_rename_profile_dialog(prof_name);
                return true;
            case R.string.proxy_context_change_proxy /*2131034309*/:
                this.proxy_spin.performClick();
                return true;
            case R.string.proxy_context_delete /*2131034310*/:
                delete_proxy_with_confirm(get_menu_key(item));
                return true;
            case R.string.proxy_context_edit /*2131034311*/:
                proxy_name = get_menu_key(item);
                if (proxy_name == null) {
                    return true;
                }
                startActivityForResult(new Intent(this, OpenVPNAddProxy.class).putExtra("net.openvpn.openvpn.PROXY_NAME", proxy_name), 0);
                return true;
            case R.string.proxy_context_forget_creds /*2131034313*/:
                proxy_name = get_menu_key(item);
                ProxyList proxy_list = get_proxy_list();
                if (proxy_list == null) {
                    return true;
                }
                proxy_list.forget_creds(proxy_name);
                proxy_list.save();
                return true;
            default:
                return RETAIN_AUTH;
        }
    }
 
    private void launch_create_profile_shortcut_dialog(final String prof_name) {
        View view = getLayoutInflater().inflate(R.layout.create_shortcut_dialog, null);
        final EditText name_field = (EditText) view.findViewById(R.id.shortcut_name);
        name_field.setText(prof_name);
        name_field.selectAll();
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        OpenVPNClient.this.createConnectShortcut(prof_name, name_field.getText().toString());
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.create_shortcut_title).setView(view).setPositiveButton(R.string.create_shortcut_yes, dialogClickListener).setNegativeButton(R.string.create_shortcut_cancel, dialogClickListener).show();
    }
 
    private void launch_rename_profile_dialog(final String orig_prof_name) {
        View view = getLayoutInflater().inflate(R.layout.rename_profile_dialog, null);
        final EditText name_field = (EditText) view.findViewById(R.id.rename_profile_name);
        name_field.setText(orig_prof_name);
        name_field.selectAll();
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        OpenVPNClient.this.submitRenameProfileIntent(orig_prof_name, name_field.getText().toString());
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.rename_profile_title).setView(view).setPositiveButton(R.string.rename_profile_yes, dialogClickListener).setNegativeButton(R.string.rename_profile_cancel, dialogClickListener).show();
    }
 
    private void delete_proxy_with_confirm(final String proxy_name) {
        final ProxyList proxy_list = get_proxy_list();
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        if (proxy_list != null) {
                            proxy_list.remove(proxy_name);
                            proxy_list.save();
                            OpenVPNClient.this.gen_ui_reset_event(OpenVPNClient.RETAIN_AUTH);
                            return;
                        }
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.proxy_delete_confirm_title).setMessage(proxy_name).setPositiveButton(R.string.proxy_delete_confirm_yes, dialogClickListener).setNegativeButton(R.string.proxy_delete_confirm_cancel, dialogClickListener).show();
    }
 
    private void forget_creds_with_confirm() {
        final Context context = this;
        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                switch (which) {
                    case -1:
                        OpenVPNClient.this.pwds.regenerate(true);
                        ProfileList proflist = OpenVPNClient.this.profile_list();
                        if (proflist != null) {
                            proflist.forget_certs();
                        }
                        TrustMan.forget_certs(context);
                        OpenVPNImportProfile.forget_server_history(OpenVPNClient.this.prefs);
                        ProxyList proxy_list = OpenVPNClient.this.get_proxy_list();
                        if (proxy_list != null) {
                            proxy_list.forget_creds();
                            proxy_list.save();
                        }
                        OpenVPNClient.this.ui_setup(OpenVPNClient.this.is_active(), OpenVPNClient.UIF_RESET, null);
                        return;
                    default:
                        return;
                }
            }
        };
        new Builder(this).setTitle(R.string.forget_creds_title).setMessage(R.string.forget_creds_message).setPositiveButton(R.string.forget_creds_yes, dialogClickListener).setNegativeButton(R.string.forget_creds_cancel, dialogClickListener).show();
    }
 
    public PendingIntent get_configure_intent(int requestCode) {
        return PendingIntent.getActivity(this, requestCode, getIntent(), PendingIntent.FLAG_IMMUTABLE);
    }
 
    private void resolve_epki_alias_then_connect() {
        resolveExternalPkiAlias(selected_profile(), new EpkiPost() {
            public void post_dispatch(String alias) {
                OpenVPNClient.this.do_connect(alias);
            }
        });
    }
 
    private void do_connect(String epki_alias) {
        String app_name = "net.maxvpn.connect.android";
        String proxy_name = null;
        String server = null;
        String username = null;
        String password = null;
        String pk_password = null;
        String response = null;
        boolean is_auth_pwd_save = RETAIN_AUTH;
        String profile_name = selected_profile_name();
        if (this.proxy_group.getVisibility() == 0) {
            ProxyList proxy_list = get_proxy_list();
            if (proxy_list != null) {
                proxy_name = proxy_list.get_enabled(RETAIN_AUTH);
            }
        }
        if (this.server_group.getVisibility() == 0) {
            server = SpinUtil.get_spinner_selected_item(this.server_spin);
        }
        if (this.username_group.getVisibility() == 0) {
            username = this.username_edit.getText().toString();
            if (username.length() > 0) {
                this.prefs.set_string_by_profile(profile_name, "username", username);
            }
        }
        if (this.pk_password_group.getVisibility() == 0) {
            pk_password = this.pk_password_edit.getText().toString();
            boolean is_pk_pwd_save = this.pk_password_save_checkbox.isChecked();
            this.prefs.set_boolean_by_profile(profile_name, "pk_password_save", is_pk_pwd_save);
            if (is_pk_pwd_save) {
                this.pwds.set("pk", profile_name, pk_password);
            } else {
                this.pwds.remove("pk", profile_name);
            }
        }
        if (this.password_group.getVisibility() == 0) {
            password = this.password_edit.getText().toString();
            is_auth_pwd_save = this.password_save_checkbox.isChecked();
            this.prefs.set_boolean_by_profile(profile_name, "auth_password_save", is_auth_pwd_save);
            if (is_auth_pwd_save) {
                this.pwds.set("auth", profile_name, password);
            } else {
                this.pwds.remove("auth", profile_name);
            }
        }
        if (this.cr_group.getVisibility() == 0) {
            response = this.response_edit.getText().toString();
        }
        clear_auth();
        String vpn_proto = this.prefs.get_string("vpn_proto");
        String ipv6 = this.prefs.get_string("ipv6");
        String conn_timeout = this.prefs.get_string("conn_timeout");
        String compression_mode = this.prefs.get_string("compression_mode");
        clear_stats();
        submitConnectIntent(profile_name, server, vpn_proto, ipv6, conn_timeout, username, password, is_auth_pwd_save, pk_password, response, epki_alias, compression_mode, proxy_name, null, null, true, get_gui_version(app_name));
    }
 
    private void import_profile(String path) {
        submitImportProfileViaPathIntent(path);
    }
 
    protected void onActivityResult(int request, int result, Intent data) {
        String str = TAG;
        Object[] objArr = new Object[S_ONSTART_CALLED];
        objArr[0] = Integer.valueOf(request);
        objArr[S_BIND_CALLED] = Integer.valueOf(result);
        Log.d(str, String.format("CLI: onActivityResult request=%d result=%d", objArr));
        String path;
        switch (request) {
            case S_BIND_CALLED /*1*/:
                if (result == -1) {
                    resolve_epki_alias_then_connect();
                    return;
                } else if (result != 0) {
                    return;
                } else {
                    if (this.finish_on_connect == FinishOnConnect.ENABLED) {
                        finish();
                        return;
                    } else if (this.finish_on_connect == FinishOnConnect.ENABLED_ACROSS_ONSTART) {
                        this.finish_on_connect = FinishOnConnect.ENABLED;
                        start_connect();
                        return;
                    } else {
                        return;
                    }
                }
            case S_ONSTART_CALLED /*2*/:
                if (result == -1) {
                    path = data.getStringExtra(FileDialog.RESULT_PATH);
                    str = TAG;
                    objArr = new Object[S_BIND_CALLED];
                    objArr[0] = path;
                    Log.d(str, String.format("CLI: IMPORT_PROFILE: %s", objArr));
                    import_profile(path);
                    return;
                }
                return;
            case REQUEST_IMPORT_PKCS12 /*3*/:
                if (result == -1) {
                    path = data.getStringExtra(FileDialog.RESULT_PATH);
                    str = TAG;
                    objArr = new Object[S_BIND_CALLED];
                    objArr[0] = path;
                    Log.d(str, String.format("CLI: IMPORT_PKCS12: %s", objArr));
                    import_pkcs12(path);
                    return;
                }
                return;
            default:
                super.onActivityResult(request, result, data);
                return;
        }
    }
 
    private TextView last_visible_edittext() {
        for (int i = 0; i < this.textgroups.length; i += S_BIND_CALLED) {
            if (this.textgroups[i].getVisibility() == 0) {
                return this.textviews[i];
            }
        }
        return null;
    }
 
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (v != last_visible_edittext()) {
            return RETAIN_AUTH;
        }
        if (action_enter(actionId, event) && this.connect_button.getVisibility() == 0) {
            onClick(this.connect_button);
        }
        return true;
    }
 
    private void req_focus(EditText editText) {
        boolean auto_keyboard = this.prefs.get_boolean("auto_keyboard", RETAIN_AUTH);
        if (editText != null) {
            editText.requestFocus();
            if (auto_keyboard) {
                raise_keyboard(editText);
                return;
            }
            return;
        }
        this.main_scroll_view.requestFocus();
        if (auto_keyboard) {
            dismiss_keyboard();
        }
    }
 
    private void raise_keyboard(EditText editText) {
        InputMethodManager mgr = (InputMethodManager) getSystemService("input_method");
        if (mgr != null) {
            mgr.showSoftInput(editText, S_BIND_CALLED);
        }
    }
 
    private void dismiss_keyboard() {
        InputMethodManager mgr = (InputMethodManager) getSystemService("input_method");
        if (mgr != null) {
            TextView[] textViewArr = this.textviews;
            int length = textViewArr.length;
            for (int i = 0; i < length; i += S_BIND_CALLED) {
                mgr.hideSoftInputFromWindow(textViewArr[i].getWindowToken(), 0);
            }
        }
    }
 
    private void load_ui_elements() {
        this.main_scroll_view = (ScrollView) findViewById(R.id.main_scroll_view);
        this.post_import_help_blurb = findViewById(R.id.post_import_help_blurb);
        this.profile_group = findViewById(R.id.profile_group);
		this.load_server_layout = findViewById(R.id.load_server_layout);
        this.proxy_group = findViewById(R.id.proxy_group);
        this.server_group = findViewById(R.id.server_group);
        this.username_group = findViewById(R.id.username_group);
        this.password_group = findViewById(R.id.password_group);
        this.pk_password_group = findViewById(R.id.pk_password_group);
        this.cr_group = findViewById(R.id.cr_group);
        this.conn_details_group = findViewById(R.id.conn_details_group);
        this.stats_group = findViewById(R.id.stats_group);
        this.stats_expansion_group = findViewById(R.id.stats_expansion_group);
        this.info_group = findViewById(R.id.info_group);
		this.select_server = (ImageView) findViewById(R.id.select_server);
        this.button_group = findViewById(R.id.button_group);
        this.profile_spin = (Spinner) findViewById(R.id.profile);
        this.profile_edit = (ImageButton) findViewById(R.id.profile_edit);
        this.proxy_spin = (Spinner) findViewById(R.id.proxy);
        this.proxy_edit = (ImageButton) findViewById(R.id.proxy_edit);
        this.server_spin = (Spinner) findViewById(R.id.server);
        this.challenge_view = (TextView) findViewById(R.id.challenge);
        this.username_edit = (TextInputEditText) findViewById(R.id.username);
        this.password_edit = (TextInputEditText) findViewById(R.id.password);
        this.pk_password_edit = (EditText) findViewById(R.id.pk_password);
        this.response_edit = (EditText) findViewById(R.id.response);
        this.password_save_checkbox = (CheckBox) findViewById(R.id.password_save);
        this.pk_password_save_checkbox = (CheckBox) findViewById(R.id.pk_password_save);
        this.status_view = (TextView) findViewById(R.id.status);
        this.status_icon_view = (ImageView) findViewById(R.id.status_icon);
		this.vip_icon = (ImageView) findViewById(R.id.vip_icon);
		this.main_rippleBackground2=(RippleBackground)findViewById(R.id.main_ripple2);
		this.main_rippleBackground=(RippleBackground)findViewById(R.id.main_ripple);
        this.progress_bar = (ProgressBar) findViewById(R.id.progress);
        this.connect_button = (Button) findViewById(R.id.connect);
		this.stop_connect = (Button) findViewById(R.id.stop_connect);
        this.disconnect_button = (Button) findViewById(R.id.disconnect);
        this.details_more_less = (TextView) findViewById(R.id.details_more_less);
        this.last_pkt_recv_view = (TextView) findViewById(R.id.last_pkt_recv);
        this.duration_view = (TextView) findViewById(R.id.duration);
        this.bytes_in_view = (TextView) findViewById(R.id.bytes_in);
        this.bytes_out_view = (TextView) findViewById(R.id.bytes_out);
        this.connect_button.setOnClickListener(this);
        this.disconnect_button.setOnClickListener(this);
        this.profile_spin.setOnItemSelectedListener(this);
        this.proxy_spin.setOnItemSelectedListener(this);
        this.server_spin.setOnItemSelectedListener(this);
        registerForContextMenu(this.profile_spin);
        registerForContextMenu(this.proxy_spin);
        findViewById(R.id.conn_details_boxed).setOnTouchListener(this);
        this.profile_edit.setOnClickListener(this);
		this.select_server.setOnClickListener(this);
		registerForContextMenu(this.select_server);
        registerForContextMenu(this.profile_edit);
        this.proxy_edit.setOnClickListener(this);
        registerForContextMenu(this.proxy_edit);
        this.username_edit.setOnEditorActionListener(this);
        this.password_edit.setOnEditorActionListener(this);
        this.pk_password_edit.setOnEditorActionListener(this);
        this.response_edit.setOnEditorActionListener(this);
        this.textgroups = new View[]{this.cr_group, this.password_group, this.pk_password_group, this.username_group};
        this.textviews = new EditText[]{this.response_edit, this.password_edit, this.pk_password_edit, this.username_edit};
    }
}
