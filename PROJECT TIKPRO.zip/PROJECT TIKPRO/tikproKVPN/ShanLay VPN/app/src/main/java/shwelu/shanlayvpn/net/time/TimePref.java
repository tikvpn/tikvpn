package shwelu.shanlayvpn.net.time;
import android.content.SharedPreferences;
import android.content.Context;
import android.preference.PreferenceManager;

public class TimePref {
    private static final String REMAINING_TIME = "remaining_time";
    
    private SharedPreferences sp;
	
	private TimePref(Context context){
		sp = PreferenceManager.getDefaultSharedPreferences(context);
	}
	
	public static TimePref getInstance(Context context){
		return new TimePref(context);
	}
	
	protected long getTime(){
		return sp.getLong(REMAINING_TIME, 0);
	}
	
	protected void saveTime(long timestamp){
		sp.edit().putLong(REMAINING_TIME, timestamp).commit();
	}
	
	protected void removeTime(){
		sp.edit().remove(REMAINING_TIME).commit();
	}
}
