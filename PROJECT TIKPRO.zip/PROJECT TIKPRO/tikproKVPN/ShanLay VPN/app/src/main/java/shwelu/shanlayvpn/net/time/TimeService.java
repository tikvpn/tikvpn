package shwelu.shanlayvpn.net.time;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import java.util.TimerTask;
import java.util.Timer;
import android.content.Context;

public class TimeService extends Service {
	
	public static final String EXTRA_TIME = "EXTRA_TIME";
	private Timer timer;
    
    @Override
    public IBinder onBind(Intent intent) {    
        return null;
    }

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		if (intent != null && intent.hasExtra(EXTRA_TIME)){
			long timestamp = intent.getLongExtra(EXTRA_TIME, 0);
			timer = new Timer();
			timer.schedule(new TimerTask(){
					@Override
					public void run() {
						Context context = getApplicationContext();
						if (context != null){
							startService(TimeAPI.buildDisconnectIntent(context));
							stopSelf();
						}
					}
				}, timestamp);
		}	
		return START_STICKY;
	}

	@Override
	public void onDestroy() {
		if (timer != null) timer.cancel();
		super.onDestroy();
	}
	
	
    
}
