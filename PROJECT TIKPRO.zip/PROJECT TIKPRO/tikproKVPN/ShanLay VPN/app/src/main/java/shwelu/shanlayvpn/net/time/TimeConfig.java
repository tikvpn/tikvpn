package shwelu.shanlayvpn.net.time;

public class TimeConfig {
	// Time is calculated in milliseconds
	
	// reward = 10 hours
    public static final long REWARD_TIME = 10 * 60 * 60 * 1000;
	
	
	// max = 500 hours
    public static final long MAX_REWARD_TIME = 500 * 60 * 60 * 1000;
    
	// bonus = 10 minutes
	public static final long BONUS_TIME = 10 * 60 * 1000;

	// add error time 2 hours
	public static long AAD_TIME = 2 * 60 * 60 * 1000;
	
    
}
