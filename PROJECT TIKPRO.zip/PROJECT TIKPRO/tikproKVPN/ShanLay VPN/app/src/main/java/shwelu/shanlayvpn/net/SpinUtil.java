package shwelu.shanlayvpn.net;

import android.content.Context;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import java.util.Arrays;
import android.widget.*;
import android.view.*;
import android.support.transition.R;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.PositionMap;
import android.graphics.Color;


public class SpinUtil {
    public static String[] get_spinner_list(Spinner spin) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return null;
        }
        int len = aa.getCount();
        String[] ret = new String[len];
        for (int i = 0; i < len; i++) {
            ret[i] = (String) aa.getItem(i);
        }
        return ret;
    }

    public static int get_spinner_count(Spinner spin) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return 0;
        }
        return aa.getCount();
    }

    public static String get_spinner_list_item(Spinner spin, int position) {
        ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
        if (aa == null) {
            return null;
        }
        return (String) aa.getItem(position);
    }

    public static String get_spinner_selected_item(Spinner spin) {
        return (String) spin.getSelectedItem();
    }

    public static void set_spinner_selected_item(Spinner spin, String selected_item) {
        if (selected_item != null) {
            String sel = get_spinner_selected_item(spin);
            if (sel == null || !selected_item.equals(sel)) {
                ArrayAdapter<String> aa = (ArrayAdapter) spin.getAdapter();
                int len = aa.getCount();
                for (int pos = 0; pos < len; pos++) {
                    if (selected_item.equals(aa.getItem(pos))) {
                        spin.setSelection(pos);
						
                    }
                }
            }
        }
    }

	public static void show_spinner(Context context, Spinner spin, String[] content) {
        if (content != null) {
            String[] live_content = get_spinner_list(spin);
            if (live_content == null || !Arrays.equals(content, live_content)) {
                SpinnerAdapter aa = new RenzAdapter(context, content);
                spin.setAdapter(aa);
            }
        }
    }
	public static class RenzAdapter extends ArrayAdapter<String>
	{
		public RenzAdapter(Context context, String[] names)
		{
			super(context, R.layout.spinner_item, names);
		}

		@Override
		public String getItem(int position)
		{
			// TODO: Implement this method
			return super.getItem(position);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return getCustomView(position, convertView, parent);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return getCustomView(position, convertView, parent);
		}
		
		
		
		
		
		
		public View getCustomView(int position, View convertView, ViewGroup parent)
		{
			
			View v = LayoutInflater.from(getContext()).inflate(R.layout.spinner_item, parent, false);
			TextView tv = (TextView)v.findViewById(R.id.spinner_item_txt);
			TextView tv_info =(TextView)v.findViewById(R.id.tv_info);
			ImageView iv = (ImageView)v.findViewById(R.id.spinner_item_image);
			ImageView iv1 = (ImageView)v.findViewById(R.id.spinner_item_image1);
			ImageView vip_ic = (ImageView)v.findViewById(R.id.vip_ic);
			
			
			String config = getItem(position);
			tv.setText(config);
			tv.setTextColor(Color.parseColor("#38BFB3"));
			
			iv.setVisibility(8);
			
		
			
			
			tv_info.setText("");
			tv_info.setTextColor(Color.parseColor("#38BFB3"));
			iv.setImageResource(android.R.drawable.ic_menu_view);
			iv1.setImageResource(android.R.drawable.ic_menu_view);
			vip_ic.setImageResource(android.R.drawable.ic_menu_view);

			Animation slideUp = AnimationUtils.loadAnimation(getContext(), R.anim.slide_in);
			tv.setAnimation(slideUp);
			tv.startAnimation(slideUp);
			iv.setAnimation(slideUp);
			iv.startAnimation(slideUp);
			iv1.setAnimation(slideUp);
			iv1.startAnimation(slideUp);
		    tv_info.setAnimation(slideUp);
			tv_info.startAnimation(slideUp);
			vip_ic.setAnimation(slideUp);
			vip_ic.startAnimation(slideUp);

			
			if (config.contains("90days")) {
				tv_info.setText("Shopping + Happy call 64kbps");
				
			    }else 
			if (config.contains("HappyWork")) {
				tv_info.setText("Happy Work");
				
				}else 	
			if (config.contains("LINE")) {
				tv_info.setText("LINE 12apps + Happy call 64kbps");
				
				}else
			if (config.contains("DtacSocial")) {
				tv_info.setText("Social 10apps");
				
				}else
			if (config.contains("TrueNoPro")) {
				tv_info.setText("No need pro");
				
				}else
			if (config.contains("DtacNoPro")) {
			    tv_info.setText("No need pro");
				tv_info.setTextColor(Color.parseColor("#38BFB3"));
				
			   }else
			if (config.contains("TrueSocial")) {
				tv_info.setText("NOPRO");
				tv_info.setTextColor(Color.parseColor("#38BFB3"));
				
				}else
			    {
				tv_info.setText("");
				}
			

			if (config.contains("JP")) {
				iv1.setImageResource(R.drawable.flag_jp);
				iv.setVisibility(0);
			} else


			if (config.contains("UK")) {
				iv1.setImageResource(R.drawable.flag_uk);
				iv.setVisibility(0);
				} else

			if (config.contains("CA")) {
				iv1.setImageResource(R.drawable.flag_ca);
				iv.setVisibility(0);
				} else

			if (config.contains("MM")) {
				iv1.setImageResource(R.drawable.flag_mm);
				iv.setVisibility(0);
				} else
			
			if (config.contains("SG")) {
				iv1.setImageResource(R.drawable.flag_sg);
				iv.setVisibility(0);
				} else
			
			
			if (config.contains("KR")) {
				iv1.setImageResource(R.drawable.flag_kr);
				iv.setVisibility(0);
				} else
			
			if (config.contains("TH")) {
				iv1.setImageResource(R.drawable.flag_th);
				iv.setVisibility(0);
				} else
			
			if (config.contains("US")) {
				iv1.setImageResource(R.drawable.flag_us);
				iv.setVisibility(0);
				} else {
				iv1.setImageResource(R.drawable.icon);
			}
			
			if (config.contains("VIP")) {
				iv1.setImageResource(R.drawable.vip);
				tv.setTextColor(ContextCompat.getColor(getContext(), R.color.colorPrimary));
				iv.setVisibility(0);
				vip_ic.setImageResource(R.drawable.vip_icon);
			} else
			
			
			if (config.contains("VIP")){
				tv.setTextColor(ContextCompat.getColor(getContext(), R.color.colorPrimary));
				vip_ic.setImageResource(R.drawable.vip_icon);
			}else if(config.contains("TH")){
				vip_ic.setImageResource(R.drawable.game_ic);
			} else{
				vip_ic.setImageResource(R.drawable.stats_box);
			}



			if (config.contains("dtac")) {
				iv.setImageResource(R.drawable.dtac);
			} else if (config.contains("DTAC")) {
				iv.setImageResource(R.drawable.dtac);
			} else if (config.contains("true")) {
				iv.setImageResource(R.drawable.truemove);
			} else if (config.contains("True")) {
				iv.setImageResource(R.drawable.truemove);
			} else if (config.contains("AIS")) {
				iv.setImageResource(R.drawable.AIS);
			} else if (config.contains("Ais")) {
				iv.setImageResource(R.drawable.AIS);
			} else if (config.contains("Dtac")) {
				iv.setImageResource(R.drawable.dtac);
			} else if (config.contains("TRUE")) {
				iv.setImageResource(R.drawable.truemove);
			} else {
				iv.setImageResource(R.drawable.stats_box);
			}
			// TODO: Implement this method
			return v;
		}

		

	}
}


