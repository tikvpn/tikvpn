package shwelu.shanlayvpn.net;

import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.widget.Toolbar;
import android.widget.ListView;
import android.widget.ImageButton;
import android.view.View.OnClickListener;
import android.view.View;
import android.content.SharedPreferences;
import android.content.Context;
import android.widget.ImageView;


public class settings extends PreferenceActivity {

	

	
	public void onCreate(Bundle savedInstanceState) {
        if (OpenVPNClientBase.themeSet) {
            setTheme(OpenVPNClientBase.themeResId);
        }
		
		SharedPreferences sharedPreferences = getSharedPreferences("theme", Context.MODE_PRIVATE);
        setTheme(sharedPreferences.getInt("themeId",OpenVPNClientBase.themeResId));
		
		super.onCreate(savedInstanceState);
		addPreferencesFromResource(R.xml.preferences);

		
		
		setContentView(R.layout.layout_preferences);
		
		
		
		ImageView exit_button = (ImageView) findViewById(R.id.exit_button);
		exit_button.setOnClickListener(new OnClickListener(){

				@Override
				public void onClick(View p1) {
					finish();
					
					
				}
				

	});


		
		// toolbar
	
		

	}

	
	
	@Override
	public void onBackPressed(){
		super.onBackPressed();
		

	}
	
	@Override
	protected void onDestroy()
	{
		// TODO: Implement this method
		super.onDestroy();

		
	}

}




